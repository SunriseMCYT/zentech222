package Zen_Tech.Touchscreen_Appliances.Horizon.For_Office_Use;
public class Horizon_Professional_P3000
{
   static double taxP3, totalP3, priceP3;
   public static void specsP3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 808\nRAM: 64 GB\nSSD: 6 TB\nGPU: Snapdragon 650");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile is good for professional users, like businessmen and office usage. \nIt has a debugging module installed in it!"
     + "\nThis phone is good for business usage This phone has a 64 hour"  
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 5.0 inch");
     System.out.println("This mobile is available in Phlox, Persian Rose, Sapphire White, Ochre Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypP3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP3 = 90000;
     System.out.println("Base Price: ₹" + priceP3);
     double taxP3 = (0.15 * priceP3);
     System.out.println("Tax Price: ₹" + taxP3);
     totalP3 = taxP3 + priceP3;
     System.out.println("Total Price: ₹" + totalP3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP3000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Professional_P3000.specsP3000(CustomerName1);
       Horizon_Professional_P3000.displaypP3000(CustomerName1);
   }
}
