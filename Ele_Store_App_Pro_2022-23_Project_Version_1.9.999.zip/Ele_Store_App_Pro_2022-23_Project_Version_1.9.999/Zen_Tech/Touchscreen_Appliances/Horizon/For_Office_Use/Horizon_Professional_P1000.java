package Zen_Tech.Touchscreen_Appliances.Horizon.For_Office_Use;
public class Horizon_Professional_P1000
{
   static double taxP1, totalP1, priceP1;
   public static void specsP1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 810\nRAM: 8 GB\nSSD: 256 GB\nGPU: Snapdragon 665");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile is good for professional users, like coders and all. \nIt has a debugging module installed in it! \nThis phone is good for business usage This phone has a 48 hour" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 4.5 inch");
     System.out.println("This mobile is available in Neon Green, Orchid, Pansy Purple, Darkrai Black Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypP1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP1 = 50000;
     System.out.println("Base Price: ₹" + priceP1);
     double taxP1 = (0.15 * priceP1);
     System.out.println("Tax Price: ₹" + taxP1);
     totalP1 = taxP1 + priceP1;
     System.out.println("Total Price: ₹" + totalP1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP1000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Professional_P1000.specsP1000(CustomerName1);
       Horizon_Professional_P1000.displaypP1000(CustomerName1);
   }
}
