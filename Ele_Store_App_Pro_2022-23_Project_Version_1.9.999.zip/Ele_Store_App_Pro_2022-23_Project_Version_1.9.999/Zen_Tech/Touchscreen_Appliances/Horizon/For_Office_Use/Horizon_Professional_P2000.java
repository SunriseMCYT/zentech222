package Zen_Tech.Touchscreen_Appliances.Horizon.For_Office_Use;
public class Horizon_Professional_P2000
{
   static double taxP2, totalP2, priceP2;
   public static void specsP2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 805\nRAM: 64 GB\nSSD: 1 TB\nGPU: Snapdragon 620");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile is good for professional users, like businessmen and office usage. \nIt has a debugging module installed in it!"
     + "\nThis phone is good for business usage This phone has a 48 hour"  
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 4.7 inch");
     System.out.println("This mobile is available in Pale Aqua, Outrageous Orange, Paris Green Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypP2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP2 = 30000;
     System.out.println("Base Price: ₹" + priceP2);
     double taxP2 = (0.15 * priceP2);
     System.out.println("Tax Price: ₹" + taxP2);
     totalP2 = taxP2 + priceP2;
     System.out.println("Total Price: ₹" + totalP2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP2000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Professional_P2000.specsP2000(CustomerName1);
       Horizon_Professional_P2000.displaypP2000(CustomerName1);
   }
}
