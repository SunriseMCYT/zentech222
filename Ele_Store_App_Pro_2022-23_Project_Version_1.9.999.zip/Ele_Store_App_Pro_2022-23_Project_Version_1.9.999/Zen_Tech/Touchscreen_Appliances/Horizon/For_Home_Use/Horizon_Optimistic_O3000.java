package Zen_Tech.Touchscreen_Appliances.Horizon.For_Home_Use;
public class Horizon_Optimistic_O3000
{
   static double taxO3, totalO3, priceO3;
   public static void specsO3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: O3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 429\nRAM: 4 GB\nSSD: 512 GB\nGPU: Snapdragon 410");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile has a 1080p camera with motion stability! It is super cool! This phone has a 4 hour" 
     + "\n(Depends on usage) battery life on 1 full charge with Super ultra fast charing!\nThe screen size is 4.5 inch");
     System.out.println("This mobile is available in Fern Green, Firebrick and French Raspberry Colours. ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypO3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO3 = 17000;
     System.out.println("Base Price: ₹" + priceO3);
     double taxO3 = (0.15 * priceO3);
     System.out.println("Tax Price: ₹" + taxO3);
     totalO3 = taxO3 + priceO3;
     System.out.println("Total Price: ₹" + totalO3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO3000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Optimistic_O3000.specsO3000(CustomerName1);
       Horizon_Optimistic_O3000.displaypO3000(CustomerName1);
   }
}
