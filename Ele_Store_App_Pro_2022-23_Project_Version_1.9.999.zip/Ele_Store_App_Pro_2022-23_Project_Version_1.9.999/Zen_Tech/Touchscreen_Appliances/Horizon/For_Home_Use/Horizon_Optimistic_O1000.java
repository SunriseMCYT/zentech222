package Zen_Tech.Touchscreen_Appliances.Horizon.For_Home_Use;
public class Horizon_Optimistic_O1000
{
   static double taxO1, totalO1, priceO1;
   public static void specsO1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: O1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 750G\nRAM: 4 GB\nSSD: 256 GB\nGPU: Snapdragon 632");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile phone has a sleek look RGB lights installed on the backside! It is super thin! This phone has a 48 hour" 
     + "\n(Depends on usage) battery life on 1 full charge with ultra fast charing!\nThe screen size is 4.3 inch");
     System.out.println("This mobile is available in Dark Green, Magneta, Royal Blue Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypO1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO1 = 25000;
     System.out.println("Base Price: ₹" + priceO1);
     double taxO1 = (0.15 * priceO1);
     System.out.println("Tax Price: ₹" + taxO1);
     totalO1 = taxO1 + priceO1;
     System.out.println("Total Price: ₹" + totalO1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO1000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Optimistic_O1000.specsO1000(CustomerName1);
       Horizon_Optimistic_O1000.displaypO1000(CustomerName1);
   }
}
