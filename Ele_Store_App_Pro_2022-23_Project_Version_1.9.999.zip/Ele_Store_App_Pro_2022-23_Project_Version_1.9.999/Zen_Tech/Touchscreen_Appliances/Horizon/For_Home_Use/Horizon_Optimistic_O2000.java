package Zen_Tech.Touchscreen_Appliances.Horizon.For_Home_Use;
public class Horizon_Optimistic_O2000
{
   static double taxO2, totalO2, priceO2;
   public static void specsO2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: O2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 860\nRAM: 4 GB\nSSD: 64 GB\nGPU: Snapdragon 427");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile phone has a smooth look with backlight camera with notification ring light! It is super thin! This phone has a 16 hour" 
     + "\n(Depends on usage) battery life on 1 full charge with Super ultra fast charing!\nThe screen size is 4.5 inch");
     System.out.println("This mobile is available in Coal Black, Denim Blue, English Violet Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypO2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO2 = 32000;
     System.out.println("Base Price: ₹" + priceO2);
     double taxO2 = (0.15 * priceO2);
     System.out.println("Tax Price: ₹" + taxO2);
     totalO2 = taxO2 + priceO2;
     System.out.println("Total Price: ₹" + totalO2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO2000(String CustomerName1)
   {
       //Call both methods.
       Horizon_Optimistic_O2000.specsO2000(CustomerName1);
       Horizon_Optimistic_O2000.displaypO2000(CustomerName1);
   }
}
