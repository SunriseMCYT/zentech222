package Zen_Tech.Touchscreen_Appliances.Horizon.For_Gaming_Use;
public class Horza_Techspeed_T3000
{
   static double taxT3, totalT3, priceT3;
   public static void specsT300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 865+\nRAM: 32 GB\nSSD: 512 GB\nGPU: Snapdragon 808");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile phone has a awesome look RGB lights installed on the backside! It has super fast charging supported! This phone has a 24 hour" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 4.6 inch");
     System.out.println("This mobile is available in Copper, Coal Black, Coquelicot  Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT3 = 65000;
     System.out.println("Base Price: ₹" + priceT3);
     double taxT3 = (0.15 * priceT3);
     System.out.println("Tax Price: ₹" + taxT3);
     totalT3 = taxT3 + priceT3;
     System.out.println("Total Price: ₹" + totalT3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationA100(String CustomerName1)
   {
       //Call both methods.
       Horza_Techspeed_T3000.specsT300(CustomerName1);
       Horza_Techspeed_T3000.displaypT3000(CustomerName1);
   }
}
