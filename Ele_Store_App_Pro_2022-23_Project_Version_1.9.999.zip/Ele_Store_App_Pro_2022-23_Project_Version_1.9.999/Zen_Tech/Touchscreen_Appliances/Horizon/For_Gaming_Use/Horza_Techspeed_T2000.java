package Zen_Tech.Touchscreen_Appliances.Horizon.For_Gaming_Use;
public class Horza_Techspeed_T2000
{
   static double taxT2, totalT2, priceT2;
   public static void specsT200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Mobile Specs: \nCPU: Qualcomm Snapdragon 870\nRAM: 16 GB\nSSD: 512 GB\nGPU: Snapdragon 636");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This mobile phone has a futuristic look RGB lights installed on the backside! It has a cooler attached to it! This phone has a 6 hour" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 4.7 inch");
     System.out.println("This mobile is available in Carribbean Green, Canary, Carmine Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT2 = 60000;
     System.out.println("Base Price: ₹" + priceT2);
     double taxT2 = (0.15 * priceT2);
     System.out.println("Tax Price: ₹" + taxT2);
     totalT2 = taxT2 + priceT2;
     System.out.println("Total Price: ₹" + totalT2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationA100(String CustomerName1)
   {
       //Call both methods.
       Horza_Techspeed_T2000.specsT200(CustomerName1);
       Horza_Techspeed_T2000.displaypT2000(CustomerName1);
   }
}
