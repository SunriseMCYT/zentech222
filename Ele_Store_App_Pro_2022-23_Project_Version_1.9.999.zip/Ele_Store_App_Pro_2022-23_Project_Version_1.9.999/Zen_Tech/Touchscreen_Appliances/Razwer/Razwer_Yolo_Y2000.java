package Zen_Tech.Touchscreen_Appliances.Razwer;
public class Razwer_Yolo_Y2000
{
   static double taxY2, totalY2, priceY2;
   public static void specsY2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Y2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Tablet Specs: \nCPU: Qualcomm Snapdragon 855\nRAM: 16 GB\nSSD: 64 GB\nGPU: Snapdragon 645");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This tab is very sleek! It is water resistant IP68 rating! With a battery life of 7 hours" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 10.4 inch");
     System.out.println("This tablet is available in Russian Violet, Scarlet, Sea Blue Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypY2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceY2 = 30000;
     System.out.println("Base Price: ₹" + priceY2);
     double taxY2 = (0.15 * priceY2);
     System.out.println("Tax Price: ₹" + taxY2);
     totalY2 = taxY2 + priceY2;
     System.out.println("Total Price: ₹" + totalY2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationY2000(String CustomerName1)
   {
       //Call both methods.
       Razwer_Yolo_Y2000.specsY2000(CustomerName1);
       Razwer_Yolo_Y2000.displaypY2000(CustomerName1);
   }
}
