package Zen_Tech.Touchscreen_Appliances.Razwer;
public class Razwer_Yolo_Y3000
{
   static double taxY3, totalY3, priceY3;
   public static void specsY3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Y3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Tablet Specs: \nCPU: Qualcomm Snapdragon 860\nRAM: 16 GB\nSSD: 64 GB\nGPU: Snapdragon 650");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This tab is very modern with one UI built in. It is water resistant IP68 rating! With a battery life of 9 hours" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 10.4 inch");
     System.out.println("This tablet is available in Shadow, Shimmering Blush, Sizzling Sunrise Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypY3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceY3 = 35000;
     System.out.println("Base Price: ₹" + priceY3);
     double taxY3 = (0.15 * priceY3);
     System.out.println("Tax Price: ₹" + taxY3);
     totalY3 = taxY3 + priceY3;
     System.out.println("Total Price: ₹" + totalY3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationY3000(String CustomerName1)
   {
       //Call both methods.
       Razwer_Yolo_Y3000.specsY3000(CustomerName1);
       Razwer_Yolo_Y3000.displaypY3000(CustomerName1);
   }
}
