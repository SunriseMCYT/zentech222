package Zen_Tech.Touchscreen_Appliances.Razwer;
public class Razwer_Yolo_Y1000
{
   static double taxY1, totalY1, priceY1;
   public static void specsY1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Y1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Tablet Specs: \nCPU: Qualcomm Snapdragon 845\nRAM: 8 GB\nSSD: 32 GB\nGPU: Snapdragon 630");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This tab is very strong! It is water resistant IP68 rating! With a battery life of 5 hours" 
     + "\n(Depends on usage) battery life on 1 full charge!\nThe screen size is 10.4 inch");
     System.out.println("This mobile is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypY1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceY1 = 25000;
     System.out.println("Base Price: ₹" + priceY1);
     double taxY1 = (0.15 * priceY1);
     System.out.println("Tax Price: ₹" + taxY1);
     totalY1 = taxY1 + priceY1;
     System.out.println("Total Price: ₹" + totalY1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationY1000(String CustomerName1)
   {
       //Call both methods.
       Razwer_Yolo_Y1000.specsY1000(CustomerName1);
       Razwer_Yolo_Y1000.displaypY1000(CustomerName1);
   }
}
