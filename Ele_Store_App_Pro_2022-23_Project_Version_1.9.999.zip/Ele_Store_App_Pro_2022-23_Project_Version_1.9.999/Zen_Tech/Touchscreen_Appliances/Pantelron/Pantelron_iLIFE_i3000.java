package Zen_Tech.Touchscreen_Appliances.Pantelron;
public class Pantelron_iLIFE_i3000
{
   static double taxi3, totali3, pricei3;
   public static void specsi3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: i3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Watch Specs: \nUpto 250 Sports Modes!\nUltra Super Fast Charge\nEmergency mode\n2.00 inch TFT display\nPantelron Lifeteime subscription for Health guide(Inc.),");
     System.out.println("Healthyify me Health suite\nPantelron Lifetime subscription for health guide(Inc.)\nCamera with 1080p resolution\nBT Face Calling");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This watch is WaterProof IP68\nColours Available: Crystal white, Scarlet Red, Iron Rust, Royal Gold");
     System.out.println("This watch will help you to show the real you in workouts and exercises.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypi3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     pricei3 = 8000;
     System.out.println("Base Price: ₹" + pricei3);
     double taxi3 = (0.15 * pricei3);
     System.out.println("Tax Price: ₹" + taxi3);
     totali3 = taxi3 + pricei3;
     System.out.println("Total Price: ₹" + totali3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationi3000(String CustomerName1)
   {
       //Call both methods.
       Pantelron_iLIFE_i3000.specsi3000(CustomerName1);
       Pantelron_iLIFE_i3000.displaypi3000(CustomerName1);
   }
}

