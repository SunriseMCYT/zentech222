package Zen_Tech.Touchscreen_Appliances.Pantelron;
public class Pantelron_iLIFE_i2000
{
   static double taxi2, totali2, pricei2;
   public static void specsi2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: i2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Watch Specs: \n100 Sports Modes!\nBT Calling\nPantelron health suite(Weight, Calorie meter, BP, Stress, SPO2 meter, etc.)\n1.69 inch TFT display");
     System.out.println("Pantelron 2 year subscriptionfor health guide(Inc.)\nPantelron 2 year subscription for health guide(Inc.)\nCamera with 1080p resolution");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This watch is WaterProof IP68\nColours Available: Submarine Grey, Aquamrine Cyan, Maroon");
     System.out.println("This watch will help you to show the real you in workouts and exercises.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypi2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     pricei2 = 8000;
     System.out.println("Base Price: ₹" + pricei2);
     double taxi2 = (0.15 * pricei2);
     System.out.println("Tax Price: ₹" + taxi2);
     totali2 = taxi2 + pricei2;
     System.out.println("Total Price: ₹" + totali2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationi2000(String CustomerName1)
   {
       //Call both methods.
       Pantelron_iLIFE_i2000.specsi2000(CustomerName1);
       Pantelron_iLIFE_i2000.displaypi2000(CustomerName1);
   }
}

