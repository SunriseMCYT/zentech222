package Zen_Tech.Touchscreen_Appliances.Pantelron;
public class Pantelron_iLIFE_i1000
{
   static double taxi1, totali1, pricei1;
   public static void specsi1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: i1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Watch Specs: \n100 Sports Modes!\nBT Calling\nPantelron health suite(Weight, Calorie meter, BP, Stress, SPO2 meter, etc.)\n1.69 inch TFT display");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This watch is WaterProof IP68\nColours Available: Jet Black, Aquamrine Blue, Vermilion Red");
     System.out.println("This watch will help you to show the real you in workouts and exercises.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypi1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     pricei1 = 10000;
     System.out.println("Base Price: ₹" + pricei1);
     double taxi1 = (0.15 * pricei1);
     System.out.println("Tax Price: ₹" + taxi1);
     totali1 = taxi1 + pricei1;
     System.out.println("Total Price: ₹" + totali1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationi1000(String CustomerName1)
   {
       //Call both methods.
       Pantelron_iLIFE_i1000.specsi1000(CustomerName1);
       Pantelron_iLIFE_i1000.displaypi1000(CustomerName1);
   }
}

