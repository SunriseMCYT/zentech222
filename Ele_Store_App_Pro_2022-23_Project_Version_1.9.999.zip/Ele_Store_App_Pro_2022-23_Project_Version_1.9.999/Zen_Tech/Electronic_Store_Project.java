package Zen_Tech;
import java.util.Scanner;
//import Subpackages of Laptops Package.
import Zen_Tech.Laptops.Forza_Galaxy.Forza_About_Us;
import Zen_Tech.Laptops.Opera.Opera_About_Us;
import Zen_Tech.Laptops.Phoenix.Phoenix_About_Us;
import Zen_Tech.Accessories.Zaag.Zaag_About_Us;
import Zen_Tech.Accessories.Scosche.Scosche_About_us;
import Zen_Tech.Accessories.Kaiser.Kaiser_About_Us;
import Zen_Tech.Accessories.Necrolt.Necrolt_About_Us;
import Zen_Tech.Home_Appliances.Kenmore.Kenmore_About_Us;
import Zen_Tech.Home_Appliances.Sophist_Homeware.Sophist_About_Us;
import Zen_Tech.Home_Appliances.Elite_Homeware.EliteHomewareAboutUS;
import Zen_Tech.Home_Appliances.Lyssarent.LyssarentAboutUS;
import Zen_Tech.Home_Appliances.Kenmore.French_Door.*;
import Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.*;
import Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.*;
import Zen_Tech.Home_Appliances.Kenmore.Quad_Door.*;
import Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.*;
import Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.*;
import Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave.*;
import Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.*;
import Zen_Tech.Accessories.Zaag.For_Office_use.*;
import Zen_Tech.Accessories.Scosche.For_Gaming_use.*;
import Zen_Tech.Accessories.Scosche.For_Student_use.*;
import Zen_Tech.Accessories.Kaiser.*;
import Zen_Tech.Accessories.Necrolt.For_Gaming_use.*;
public class Electronic_Store_Project
{
    //Only For Laptop.
    static int total, price;
    public void Forza_About_Us()
    {
        Forza_About_Us.display();
    }

    public void Opera_About_Us()
    {
        Opera_About_Us.display();  
    }

    public void Phoenix_About_Us()
    {
        Phoenix_About_Us.display();  
    }

    public void Laptop_Display()
    {
        //Laptops Display Caller for about us.
        Forza_About_Us();
        Opera_About_Us();
        Phoenix_About_Us();
    }

    public static void Laptop_About_Us_Program_Beta()
    {
        Electronic_Store_Project nonstaticcaller= new Electronic_Store_Project();
        nonstaticcaller.Laptop_Display();
    }
    static int total1, price1;
    public void Zaag_About_Us()
    {
        Zaag_About_Us.display();
    }

    public void Scosche_About_Us()
    {
        Scosche_About_us.display();  
    }

    public void Kaiser_About_Us()
    {
        Kaiser_About_Us.display();  
    }

    public void Necrolt_About_Us()
    {
        Necrolt_About_Us.display();  
    }

    public void Accessories_Display()
    {
        //Laptops Display Caller for about us.
        Zaag_About_Us();
        Scosche_About_Us();
        Necrolt_About_Us();
        Kaiser_About_Us();
    }

    public static void Accessories_About_Us_Program_Beta()
    {
        Electronic_Store_Project nonstaticcaller= new Electronic_Store_Project();
        nonstaticcaller.Accessories_Display();
    }
    //Only for Home_Appliances
    static int Total3, Price3;
    public void Kenmore_About_Us()
    {
        Kenmore_About_Us.display();
    }

    public void Sophist_About_Us()
    {
        Sophist_About_Us.display();
    }
    
    public void EliteHomewareAboutUS()
    {
        EliteHomewareAboutUS.display();
    }
    
    public void LyssarentAboutUS()
    {
        LyssarentAboutUS.display();
    }

    public void Home_Appliances_Display()
    {
        //Home Appliances caller for about us.
        Kenmore_About_Us();
        Sophist_About_Us();
        EliteHomewareAboutUS();
        LyssarentAboutUS();
    }

    public static void Home_Appliances_About_Us_Program_Beta()
    {
        Electronic_Store_Project nonstaticcaller= new Electronic_Store_Project();
        nonstaticcaller.Home_Appliances_Display();
    }

    public void checkoutdetailstorage(int num, String Name)
    {
        //9000 serial no. is Home Appliances
        if(num == 9000)
        {
            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P100.displayP100(Name);
            Kenmore_Pro_P100 nonstaticcaller = new Kenmore_Pro_P100();
            double total = nonstaticcaller.totalP1;
            checkoutframework(total);
        }
        if(num == 9001)
        {
            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P200.displayP200(Name);
            Kenmore_Pro_P200 nonstaticcaller= new Kenmore_Pro_P200();
            double total = nonstaticcaller.totalP2;
            checkoutframework(total);
        }
        if(num == 9002)
        {
            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P300.displaypP300(Name);
            Kenmore_Pro_P300 nonstaticcaller = new Kenmore_Pro_P300();
            double total = nonstaticcaller.totalP3;
            checkoutframework(total);
        }
        if(num == 9003)
        {
            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T100.displaypT100(Name);
            Kenmore_Tech_T100 nonstaticcaller = new Kenmore_Tech_T100();
            double total = nonstaticcaller.totalT1;
            checkoutframework(total);
        }
        if(num == 9004)
        {
            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T200.displaypT200(Name);
            Kenmore_Tech_T200 nonstaticcaller = new Kenmore_Tech_T200();
            double total = nonstaticcaller.totalT2;
            checkoutframework(total);
        }
        if(num == 9005)
        {
            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T300.displaypT300(Name);
            Kenmore_Tech_T300 nonstaticcaller = new Kenmore_Tech_T300();
            double total = nonstaticcaller.totalT3;
            checkoutframework(total);
        }
        if(num == 9006)
        {
            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K100.displaypK100(Name);
            Kenmore_Kool_K100 nonstaticcaller = new Kenmore_Kool_K100();
            double total = nonstaticcaller.totalK1;
            checkoutframework(total);
        }
        if(num == 9007)
        {
            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K200.displaypK200(Name);
            Kenmore_Kool_K200 nonstaticcaller = new Kenmore_Kool_K200();
            double total = nonstaticcaller.totalK2;
            checkoutframework(total);
        }
        if(num == 9008)
        {
            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K300.displaypK300(Name);
            Kenmore_Kool_K300 nonstaticcaller = new Kenmore_Kool_K300();
            double total = nonstaticcaller.totalK3;
            checkoutframework(total);
        }
        if(num == 9009)
        {
            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S100.displaypS100(Name);
            Sophist_S100 nonstaticcaller = new Sophist_S100();
            double total = nonstaticcaller.totalS1;
            checkoutframework(total);
        }
        if(num == 9010)
        {
            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S200.displaypS200(Name);
            Sophist_S200 nonstaticcaller = new Sophist_S200();
            double total = nonstaticcaller.totalS2;
            checkoutframework(total);
        }
        if(num == 9011)
        {
            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S300.displaypS300(Name);
            Sophist_S300 nonstaticcaller = new Sophist_S300();
            double total = nonstaticcaller.totalS3;
            checkoutframework(total);
        }
        if(num == 9012)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.Sophist_S300.displaypMw100(Name);
            Sophist_Mw100 nonstaticcaller = new Sophist_Mw100();
            double total = nonstaticcaller.totalMw1;
            checkoutframework(total);
        }
        if(num == 9013)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.displaypMw200(Name);
            Sophist_Mw200 nonstaticcaller = new Sophist_Mw200();
            double total = nonstaticcaller.totalMw2;
            checkoutframework(total);
        }
        if(num == 9014)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.displaypMw300(Name);
            Sophist_Mw300 nonstaticcaller = new Sophist_Mw300();
            double total = nonstaticcaller.totalMw3;
            checkoutframework(total);
        }
        if(num == 9015)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.displaypMc100(Name);
            Sophist_Mc100 nonstaticcaller = new Sophist_Mc100();
            double total = nonstaticcaller.totalMc1;
            checkoutframework(total);
        }
        if(num == 9016)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.displaypMc200(Name);
            Sophist_Mc200 nonstaticcaller = new Sophist_Mc200();
            double total = nonstaticcaller.totalMc200;
            checkoutframework(total);
        }if(num == 9017)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.displaypMc300(Name);
            Sophist_Mc300 nonstaticcaller = new Sophist_Mc300();
            double total = nonstaticcaller.totalMc3;
            checkoutframework(total);
        }
        if(num == 9018)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave.displaypMr100(Name);
            Sophist_Mr100 nonstaticcaller = new Sophist_Mr100();
            double total = nonstaticcaller.totalMr1;
            checkoutframework(total);
        }
        if(num == 9019)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.displaypMr200(Name);
            Sophist_Mr200 nonstaticcaller = new Sophist_Mr200();
            double total = nonstaticcaller.totalMr2;
            checkoutframework(total);
        }
        if(num == 9020)
        {
            Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.displaypMr300(Name);
            Sophist_Mr300 nonstaticcaller = new Sophist_Mr300();
            double total = nonstaticcaller.totalMr3;
            checkoutframework(total);
        }
        if(num == 9021)
        {
            Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.displaypDWA424FY(Name);
            Sophist_DWA424FY nonstaticcaller = new Sophist_DWA424FY();
            double total = nonstaticcaller.totalDWA424FY;
            checkoutframework(total);
        }
        if(num == 9022)
        {
            Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.displaypDWB535FY(Name);
            Sophist_DWB535FY nonstaticcaller = new Sophist_DWB535FY();
            double total = nonstaticcaller.totalDWB535FY;
            checkoutframework(total);
        }
        if(num == 9023)
        {
            Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.displaypDWC646FY(Name);
            Sophist_DWC646FY nonstaticcaller = new Sophist_DWC646FY();
            double total = nonstaticcaller.totalDWC646FY;
            checkoutframework(total);
        }
        if(num == 9024)
        {
            Zen_Tech.Accessories.Zaag.For_Office_use.displayQ1000(Name);
            Zaag_Ultra_Q1000 nonstaticcaller = new Zaag_Ultra_Q1000();
            double total = nonstaticcaller.totalQ1000;
            checkoutframework(total);
        }
        if(num == 9025)
        {
            Zen_Tech.Accessories.Zaag.For_Office_use.displayQ2000(Name);
            Zaag_Ultra_Q2000 nonstaticcaller = new Zaag_Ultra_Q2000();
            double total = nonstaticcaller.totalQ2000;
            checkoutframework(total);
        }
        if(num == 9026)
        {
            Zen_Tech.Accessories.Zaag.For_Office_use.displayQ3000(Name);
            Zaag_Ultra_Q3000 nonstaticcaller = new Zaag_Ultra_Q3000();
            double total = nonstaticcaller.totalQ3000;
            checkoutframework(total);
        }
        if(num == 9027)
        {
            Zen_Tech.Accessories.Scosche.For_Gaming_use.displayS1000(Name);
            Scoshe_Tyra_S1000 nonstaticcaller = new Scoshe_Tyra_S1000();
            double total = nonstaticcaller.totalS1000;
            checkoutframework(total);
        }
        if(num == 9028)
        {
            Zen_Tech.Accessories.Scosche.For_Gaming_use.displayS2000(Name);
            Scoshe_Tyra_S2000 nonstaticcaller = new Scoshe_Tyra_S2000();
            double total = nonstaticcaller.totalS2000;
            checkoutframework(total);
        }
        if(num == 9029)
        {
            Zen_Tech.Accessories.Scosche.For_Gaming_use.displayS3000(Name);
            Scoshe_Tyra_S3000 nonstaticcaller = new Scoshe_Tyra_S3000();
            double total = nonstaticcaller.totalS3000;
            checkoutframework(total);
        }
        if(num == 9028)
        {
            Zen_Tech.Accessories.Scosche.For_Student_use.displayT1000(Name);
            Scoshe_Austra_T1000 nonstaticcaller = new Scoshe_Austra_T1000();
            double total = nonstaticcaller.totalT1000;
            checkoutframework(total);
        }
        if(num == 9030)
        {
            Zen_Tech.Accessories.Scosche.For_Student_use.displayT2000(Name);
            Scoshe_Austra_T2000 nonstaticcaller = new Scoshe_Austra_T2000();
            double total = nonstaticcaller.totalT2000;
            checkoutframework(total);
        }
        if(num == 9031)
        {
            Zen_Tech.Accessories.Scosche.For_Student_use.displayT3000(Name);
            Scoshe_Austra_T3000 nonstaticcaller = new Scoshe_Austra_T3000();
            double total = nonstaticcaller.totalT3000;
            checkoutframework(total);
        }
        if(num == 9032)
        {
            Zen_Tech.Accessories.Kaiser.displayJ1000(Name);
            Kaiser_Elite_J1000 nonstaticcaller = new Kaiser_Elite_J1000();
            double total = nonstaticcaller.totalJ1000;
            checkoutframework(total);
        }
        if(num == 9033)
        {
            Zen_Tech.Accessories.Kaiser.displayJ2000(Name);
            Kaiser_Elite_J2000 nonstaticcaller = new Kaiser_Elite_J2000();
            double total = nonstaticcaller.totalJ2000;
            checkoutframework(total);
        }
        if(num == 9034)
        {
            Zen_Tech.Accessories.Kaiser.displayJ3000(Name);
            Kaiser_Elite_J3000 nonstaticcaller = new Kaiser_Elite_J3000();
            double total = nonstaticcaller.totalJ3000;
            checkoutframework(total);
        }
        if(num == 9035)
        {
            Zen_Tech.Accessories.Necrolt.For_Gaming_use.Necrolt_Zwift_F1000.displaypF1000(Name);
            Necrolt_Zwift_F1000 nonstaticcaller = new Necrolt_Zwift_F1000();
            double total = nonstaticcaller.totalF1000;
            checkoutframework(total);
        }
        if(num == 9036)
        {
            Zen_Tech.Accessories.Necrolt.For_Gaming_use.Necrolt_Zwift_F2000.displaypF2000(Name);
            Necrolt_Zwift_F2000 nonstaticcaller = new Necrolt_Zwift_F2000();
            double total = nonstaticcaller.totalF2000;
            checkoutframework(total);
        }
        if(num == 9037)
        {
            Zen_Tech.Accessories.Necrolt.For_Office_use.displayF000(Name);
            Kaiser_Elite_F3000 nonstaticcaller = new Kaiser_Elite_F3000();
            double total = nonstaticcaller.totalF3000;
            checkoutframework(total);
        }
    }
    
    public void checkoutframework(double total)
    {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Do you have any coupon code?\nIf yes write the coupon code, if no please write 0.");
        int CouponCode = scnr.nextInt();
        switch(CouponCode)
        {
            case 0: 
                    System.out.println("No Coupon code.");
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");
                    break;
                    
            case 937436203: 
                    System.out.println("10% Coupon code, applied.");
                    total = total - 10/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");
                    break;
                   
            case 639237018: 
                    System.out.println("20% Coupon code, applied.");
                    total = total - 20/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");     
                    break;
                   
            case 843208005: 
                    System.out.println("25% Coupon code, applied.");
                    total = total - 25/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");         
                    break;
                   
            case 100056218: 
                    System.out.println("30% Coupon code, applied.");
                    total = total - 30/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");         
                    break;
                   
            case 206571050: 
                    System.out.println("35% Coupon code, applied.");
                    total = total - 35/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");         
                    break;     
                    
            case 390265829: 
                    System.out.println("50% Coupon code, applied.");
                    total = total - 50/total;
                    System.out.println("You're total bill is ₹" + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");         
                    break;        
                   
            case 694206969:
                    System.out.println("100% Coupon code, applied.\nJackpot!!!!!!!\nYou got the world's rarest coupon code!\nHappy Buying!");
                    total = 0.00;
                    System.out.println("You're total bill is " + total);
                    System.out.println("Aye! Nice choice!\nPay now and make the item yours!");
                    System.out.println("Payment Option available is only UPI\nAs we are in developement stage prefer using UPI only!");
                    System.out.println("UPI ID: amritsinha.famc@idfcbank");         
                    break;            
        }
    }
    
    public static void Zen_Tech()
    {
       Electronic_Store_Project nonstaticcaller= new Electronic_Store_Project();
       Scanner scnr = new Scanner(System.in);
       System.out.println("Hello Customer, Please Enter Your Name : ");
       String Name = scnr.nextLine();
       String NameGlobal = Name;
       nonstaticcaller.Zen_Tech_2(NameGlobal);
    }

    public void CheckoutDialogueLoader(int SerialNo, String Name)
    { Scanner scnr = new Scanner(System.in);
      System.out.println("Would you like to checkout? \nPlease type Y for Yes and N for no.");
      char Checkoutopt = scnr.next().charAt(0);
      if(Checkoutopt == 'Y')
      {
        System.out.println("Ok " + Name + " ,taking you to checkout page.");
        System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
        int Product = SerialNo;
        checkoutdetailstorage(Product, Name);
      }
      if(Checkoutopt == 'N')
      {
         System.out.println("Ok, taking you back to main menu.");
         Zen_Tech_2(Name);
      }
      if((Checkoutopt != 'N') && (Checkoutopt != 'Y'))
      {
        System.out.println("OOPS! You've selected an incorrect option please try again!");
        scnr.close();
      }                                                  
    }
    
    public void Zen_Tech_2(String Name)
    {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Welcome " + Name +", What Would You Like To Buy?\n Please write\n1) a for Laptop\n2) b for Touchscreen Appliances\n3) c for Home Appliances\n4) d for Accesories ");
        char opt = scnr.next().charAt(0);
        if(opt == 'a')
        {
            opt = 1;
        }
        if(opt == 'b')
        {
            opt = 2;
        }
        if(opt == 'c')
        {
            opt = 3;
        }
        if(opt == 'd')
        {
            opt = 4;
        }
        switch(opt)
        {
            case 1: System.out.println("Dear " + Name + ", you have selected the category 'Laptops' ");
                System.out.println(" Please select what you want to buy \n1)A for Forza Galaxy  \n2)B for Opera \n3)C for Phoenix ");
                char Category_Laptops = scnr.next().charAt(0);
                if (Category_Laptops == 'A')
                {
                    System.out.println("There are only 3 categories:-\n1) A for Gaming Use \n2) B for Office Use\n3) C for Student Use ");
                    char Laptop_Variable = scnr.next().charAt(0);
                    if(Laptop_Variable == 'A')
                    {
                        System.out.println("You've selected Gaming Use . Please type \n1) A for A100\n2) B for A200\n3) C for A300 ");
                        char A = scnr.next().charAt(0);
                        if(A == 'A')
                        {
                            Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use.Forza_Galaxy_God_Gaming_A100.full_documentationA100(Name);
                        }
                        if(A == 'B')
                        {
                             Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use.Forza_Galaxy_God_Gaming_A200.full_documentationA200(Name);
                        }
                        if(A == 'C')
                        {
                             Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use.Forza_Galaxy_God_Gaming_A300.full_documentationA300(Name);
                        }
                    }
                    if(Laptop_Variable == 'B')
                    {
                        System.out.println("You've selected Office Use. Please type \n1) A for M100\n2) B for M200\n3) C for M300");
                        char B = scnr.next().charAt(0);
                        if(B == 'A')
                        {
                            Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use. Forza_Galaxy_Specter_M100.full_documentationM100(Name);
                        }
                        if(B == 'B')
                        {
                            Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use. Forza_Galaxy_Specter_M200.full_documentationM200(Name);
                        }
                        if(B == 'C')
                        {
                            Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use. Forza_Galaxy_Specter_M300.full_documentationM300(Name);
                        }
                    }
                    if(Laptop_Variable == 'C')
                    {
                        System.out.println("You've selected Student Use. Please type \n1) A for V100\n2) B for V200\n3) C for V300");
                        char C = scnr.next().charAt(0);
                        if(C == 'A')
                        {
                            Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use.Forza_Galaxy_Vision_V100.full_documentationV100(Name);
                        }
                        if(C == 'B')
                        {
                             Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use.Galaxy_Vision_V200.full_documentationV200(Name);
                        }
                        if(C == 'C')
                        {
                             Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use.Galaxy_Vision_V300.full_documentationV300(Name);
                        }
                    }
                }
                if (Category_Laptops == 'B')
                    {
                        System.out.println("There are only 3 categories:-\n1) A for Gaming Use\n2) B for Office Use\n3) C for Student Use");
                        char Laptop_Variable_2 = scnr.next().charAt(0);
                        if(Laptop_Variable_2 == 'A')
                        {
                            System.out.println("You've selected Gaming Use. Please type \n1) A for G100\n2) B for G200\n3) C for G300");
                            char A = scnr.next().charAt(0);
                            if(A == 'A')
                            {
                                Zen_Tech.Laptops.Opera.For_Gaming_Use.Opera_Fireyzen_G100.full_documentationG100(Name);
                            }
                            if(A == 'B')
                            {
                                Zen_Tech.Laptops.Opera.For_Gaming_Use.Opera_Fireyzen_G200.full_documentationG200(Name);
                            }
                            if(A == 'C')
                            {
                               Zen_Tech.Laptops.Opera.For_Gaming_Use.Opera_Fireyzen_G300.full_documentationG300(Name);
                            }
                        }
                        if(Laptop_Variable_2 == 'B')
                        {
                            System.out.println("You've selected Office Use. Please type \n1) A for V100\n2) B for V200\n3) C for V300");
                            char B = scnr.next().charAt(0);
                            if(B == 'A')
                            {
                                Zen_Tech.Laptops.Opera.For_Office_Use.Opera_Victor_V100.full_documentationV100(Name);
                            }
                            if(B == 'B')
                            {
                                Zen_Tech.Laptops.Opera.For_Office_Use.Opera_Victor_V200.full_documentationV200(Name);
                            }
                            if(B == 'C')
                            {
                                Zen_Tech.Laptops.Opera.For_Office_Use.Opera_Victor_V300.full_documentationV300(Name);                           
                            }
                        }
                        if(Laptop_Variable_2 == 'C')
                        {
                            System.out.println("You've selected Student Use. Please type \n1) A for S100\n2) B for S200\n3) C for S300");
                            char C = scnr.next().charAt(0);
                            if(C == 'A')
                            {
                                Zen_Tech.Laptops.Opera.For_Student_Use.Opera_Smart_S100.full_documentationS100(Name);
                            }
                            if(C == 'B')
                            {
                                Zen_Tech.Laptops.Opera.For_Student_Use.Opera_Smart_S200.full_documentationS200(Name);
                            }
                            if(C == 'C')
                            {
                                Zen_Tech.Laptops.Opera.For_Student_Use.Opera_Smart_S300.full_documentationS300(Name);
                            }
                        }
                    }
                 if (Category_Laptops == 'C')
                {
                    System.out.println("There are only 3 categories:- \n1) A for Gaming Use\n2) B for Office Use\n3) C for Student Use ");
                    char Laptop_Variable_3 = scnr.next().charAt(0);
                    if(Laptop_Variable_3 == 'A')
                    {
                        System.out.println("You've selected Gaming Use. Please type \n1) A for R100\n2) B for R200\n3) C for R300");
                        char A = scnr.next().charAt(0);
                        if(A == 'A')
                        {
                             Zen_Tech.Laptops.Phoenix.For_Gaming_Use.Phoenix_Rise_R100.full_documentationR100(Name);
                        }
                        if(A == 'B')
                        {
                             Zen_Tech.Laptops.Phoenix.For_Gaming_Use.Phoenix_Rise_R200.full_documentationR200(Name);
                        }
                        if(A == 'C')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Gaming_Use.Phoenix_Rise_R300.full_documentationR300(Name);
                        }
                    }
                    if(Laptop_Variable_3 == 'B')
                    {
                        System.out.println("You've selected Office Use. Please type \n1) A for E100\n2) B for E200\n3) C for E300");
                        char B = scnr.next().charAt(0);
                        if(B == 'A')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Office_Use.Phoenix_Excellence_E100.full_documentationE100(Name);
                        }
                        if(B == 'B')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Office_Use.Phoenix_Excellence_E200.full_documentationE200(Name);
                        }
                        if(B == 'C')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Office_Use.Phoenix_Excellence_E300.full_documentationE300(Name);
                        }
                    }  
                        if(Laptop_Variable_3 == 'C')
                    {
                        System.out.println("You've selected Student Use. Please type \n1) A for L100\n2) B for L200\n3) C for L300");
                        char C = scnr.next().charAt(0);
                        if(C == 'A')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Student_Use.Phoenix_Latitude_L100.full_documentationL100(Name);
                        }
                        if(C == 'B')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Student_Use.Phoenix_Latitude_L200.full_documentationL200(Name);
                        }
                        if(C == 'C')
                        {
                            Zen_Tech.Laptops.Phoenix.For_Student_Use.Phoenix_Latitude_L300.full_documentationL300(Name);
                        }
                    } 
                }
                break;
            case 2: System.out.println("Dear " + Name + ", you have selected the category 'Touchscreen Appliances' ");
                    System.out.println("Please select what you want to buy \n1)A for Horizon\n2)B for Pantelron \n3)C for Razwer");
                    char CatBrand = scnr.next().charAt(0);
                  if(CatBrand == 'A')
                    {
                        System.out.println("Please select");
                    }
                break;
            case 3: System.out.println("Dear " + Name + ", you have selected the category 'Home Appliances' ");
                    System.out.println(" Please select what you want to buy /n1) A for Fridge  /n2)B  for Microwave /n3)C for TV /n4)D for Dishwasher");
                    char catHA = scnr.next().charAt(0);
                if (catHA == 'A')
                {
                    System.out.println("There are only 4 categories:-\n1) A for French door\n2) B for Top freezer\n3) C for Bottom freezer\n4) D for Quad door");
                    char HAvar = scnr.next().charAt(0);
                    if(HAvar == 'A')
                    {
                        System.out.println("You've selected French Door. Please type \n1) A for P100\n2) B for P200\n3) C for P300");
                        char FDHA = scnr.next().charAt(0);
                        if(FDHA == 'A')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P100.full_documentationP100(Name);
                            int SerialNo = 9000;
                            CheckoutDialogueLoader(SerialNo, Name);
                        }
                        if(FDHA == 'B')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P200.full_documentationP200(Name);
                            int SerialNo = 9001;
                            CheckoutDialogueLoader(SerialNo, Name);
                        }
                        if(FDHA == 'C')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.French_Door.Kenmore_Pro_P300.full_documentationP300(Name);
                            int SerialNo = 9002;
                            CheckoutDialogueLoader(SerialNo, Name);
                        }    
                    if(HAvar == 'B')
                    {
                        System.out.println("You've selected Top freezer. Please type \n1) A for T100\n2) B for T200\n3) C for T300");
                        char TFHA = scnr.next().charAt(0);
                        if(TFHA == 'A')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T100.full_documentationT100(Name);
                        }
                        if(TFHA == 'B')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T200.full_documentationT200(Name);
                        }
                        if(TFHA == 'C')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Top_Freezer.Kenmore_Tech_T300.full_documentationT300(Name);
                        }
                    }
                    if(HAvar == 'C')
                    {
                        System.out.println("You've selected Bottom freezer. Please type \n1) A for K100\n2) B for K200\n3) C for K300");
                        char BFHA = scnr.next().charAt(0);
                        if(BFHA == 'A')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K100.full_documentationK100(Name);
                        }
                        if(BFHA == 'B')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K200.full_documentationK200(Name);
                        }
                        if(BFHA == 'C')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer.Kenmore_Kool_K300.full_documentationK300(Name);
                        }
                    }
                    if(HAvar == 'D')
                    {
                        System.out.println("You've selected Quad door. Please type \n1) A for S100\n2) B for S200\n3) C for S300");
                        char QDHA = scnr.next().charAt(0);
                        if(QDHA == 'A')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S100.full_documentationS100(Name);
                        }
                        if(QDHA == 'B')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S200.full_documentationS200(Name);
                        }
                        if(QDHA == 'C')
                        {
                            Zen_Tech.Home_Appliances.Kenmore.Quad_Door.Sophist_S300.full_documentationS300(Name);
                        }
                    }
                }
                if (catHA == 'B')
                    {
                        System.out.println("There are only 3 categories:-\n1) A for Solo microwave\n2) B for Grilled microwave\n3) C for Convection microwave");
                        char HAvar1 = scnr.next().charAt(0);
                        if(HAvar1 == 'A')
                        {
                            System.out.println("You've selected Solo Microwave. Please type 1) A for Mw100\n2) B for Mw200\n3) C for Mw300");
                            char SMHA = scnr.next().charAt(0);
                            if(SMHA == 'A')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.Sophist_Mw100.full_documentationMw100(Name);
                            }
                            if(SMHA == 'B')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.Sophist_Mw200.full_documentationMw200(Name);
                            }
                            if(SMHA == 'C')
                            {
                               Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave.Sophist_Mw300.full_documentationMw300(Name);
                            }
                        }
                        if(HAvar1 == 'B')
                        {
                            System.out.println("You've selected Grilled Microwave. Please type 1) A for Mc100\n2) B for Mc200\n3) C for Mc300");
                            char GMHA = scnr.next().charAt(0);
                            if(GMHA == 'A')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.Sophist_Mc100.full_documentationMc100(Name);
                            }
                            if(GMHA == 'B')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.Sophist_Mc200.full_documentationMc200(Name);
                            }
                            if(GMHA == 'C')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave.Sophist_Mc300.full_documentationMc300(Name);
                            }
                        }
                        if(HAvar1 == 'C')
                        {
                            System.out.println("You've selected Convection Microwave. Please type 1) A for Mr100\n2) B for Mr200\n3) C for Mr300");
                            char CMHA = scnr.next().charAt(0);
                            if(CMHA == 'A')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave.Sophist_Mr100.full_documentationMr100(Name);
                            }
                            if(CMHA == 'B')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave.Sophist_Mr200.full_documentationMr200(Name);
                            }
                            if(CMHA == 'C')
                            {
                                Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave.Sophist_Mr300.full_documentationMr300(Name);
                            }
                        }
                    }
                        
                if (catHA == 'C')
                {
                    System.out.println("There are only 3 categories:-\n1) A for LED\n2) B for OLED\n3) C for QLED\n4)");
                    char HAvar2 = scnr.next().charAt(0);
                    if(HAvar2 == 'A')
                    {
                        System.out.println("You've selected LED. Please type 1) A for E100\n2) B for E500\n3) C for E1000");
                        char LED = scnr.next().charAt(0);
                        if(LED == 'A')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.LED.LED_32Inches.full_documentationE100(Name);
                        }
                        if(LED == 'B')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.LED.LED_43Inches.full_documentationE500(Name);
                        }
                        if(LED == 'C')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.LED.LED_50Inches.full_documentationE1000(Name);
                        }
                    }
                    if(HAvar2 == 'B')
                    {
                        System.out.println("You've selected OLED. Please type 1) A for O1000\n2) B for O2000\n3) C for O3000");
                        char OLED= scnr.next().charAt(0);
                        if(OLED == 'A')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.OLED.OLED_48Inches.full_documentationO1000(Name);
                        }
                        if(OLED == 'B')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.OLED.OLED_55Inches.full_documentationO2000(Name);
                        }
                        if(OLED == 'C')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.OLED.OLED_65Inches.full_documentationO3000(Name);
                        }
                    }  
                        if(HAvar2 == 'C')
                    {
                        System.out.println("You've selected QLED. Please type 1) A for Q1000\n2) B for Q2000\n3) C for Q3000");
                        char QLED = scnr.next().charAt(0);
                        if(QLED == 'A')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.QLED.QLED_50Inches.full_documentationQ1000(Name);
                        }
                        if(QLED == 'B')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.QLED.QLED_55Inches.full_documentationQ2000(Name);
                        }
                        if(QLED == 'C')
                        {
                            Zen_Tech.Home_Appliances.Elite_Homeware.QLED.QLED_65Inches.full_documentationQ3000(Name);
                        }
                    } 
                }
                if (catHA == 'D')
                    {
                        System.out.println("There is only 1 category:-\n1) A for Dishwasher");
                        char DWHA = scnr.next().charAt(0);
                        if(DWHA == 'A')
                        {
                            System.out.println("You've selected Dishwasher. Please type 1) A for Built-In Dishwasher\n2) B for Portable Dishwasher \n3) C for Under-Counter");
                            char DWHA1 = scnr.next().charAt(0);
                            if(DWHA1 == 'A')
                            {
                                Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.Built_In.full_documentationDWA424FY(Name);
                            }
                            if(DWHA1 == 'B')
                            {
                                Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.Portable.full_documentationDWB535FY(Name);
                            }
                            if(DWHA1 == 'C')
                            {
                            Zen_Tech.Home_Appliances.Lyssarent.Dishwasher.UnderCounter.full_documentationDWC646FY(Name);
                            }
                        }
                    }
                }
                    break;
                case 4: System.out.println("Dear " + Name + ", you have selected the category 'Accessories' ");
                System.out.println("Pleases select what you want to buy ?\n1)A for Powerbank \n2)B for Headset \n3)C for Charger\n4)D for Mouse,Keyboards or Wifi-router");
                char catA = scnr.next().charAt(0);
                
                if(catA == 'A')
                {
                    System.out.println("There is only One category for Powerbank.\n1)A for Q1000\n2)B for Q2000\n3)C for Q3000");
                    char Pvar = scnr.next().charAt(0);
                    if(Pvar == 'A')
                    {
                        Zen_Tech.Accessories.Zaag.For_Office_use.Zaag_Ultra_Q1000.full_documentationQ1000(Name);
                    }
                    if(Pvar == 'B')
                    {
                        Zen_Tech.Accessories.Zaag.For_Office_use.Zaag_Ultra_Q2000.full_documentationQ2000(Name);
                    }
                    if(Pvar == 'C')
                    {
                        Zen_Tech.Accessories.Zaag.For_Office_use.Zaag_Ultra_Q3000.full_documentationQ3000(Name);
                    }
                }
                if(catA == 'B')
                {
                    System.out.println("There are only Two categories for this package.\n1)A for Student use\n2)B for Gaming use");
                    char hvar = scnr.next().charAt(0);
                    if(hvar == 'A')
                    {
                        System.out.println("Choose one product:\n1)A for T1000\n2)B for T2000\n3)C for T3000");
                        char Hin = scnr.next().charAt(0);
                        if(Hin == 'A')
                        {
                            Zen_Tech.Accessories.Scosche.For_Student_use.Scosche_Austra_T1000.full_documentationT1000(Name);
                        }
                        if(Hin == 'B')
                        {
                            Zen_Tech.Accessories.Scosche.For_Student_use.Scosche_Austra_T2000.full_documentationT2000(Name);
                        }
                        if(Hin == 'C')
                        {
                            Zen_Tech.Accessories.Scosche.For_Student_use.Scosche_Austra_T3000.full_documentationT3000(Name);
                        }
                    }
                    if(hvar == 'B')
                    {
                        System.out.println("Choose one product:\n1)A for S1000\n2)B for S2000\n3)C for S3000");
                        char Hin = scnr.next().charAt(0);
                        if(Hin == 'A')
                        {
                            Zen_Tech.Accessories.Scosche.For_Gaming_use.Scosche_Tyra_S1000.full_documentationS1000(Name);
                        }
                        if(Hin == 'B')
                        {
                            Zen_Tech.Accessories.Scosche.For_Gaming_use.Scosche_Tyra_S2000.full_documentationS2000(Name);
                        }
                        if(Hin == 'C')
                        {
                            Zen_Tech.Accessories.Scosche.For_Gaming_use.Scosche_Tyra_S3000.full_documentationS3000(Name);
                        }
                    }
                }    
                if(catA == 'C')
                {
                    System.out.println("There is only One category for Charger.\n1)A for J1000\n2)B for J2000\n3)C for J3000");
                    char Cvar = scnr.next().charAt(0);
                    if(Cvar == 'A')
                    {
                        Zen_Tech.Accessories.Kaiser.Kaiser_Elite_J1000.full_documentationJ1000(Name);
                    }
                    if(Cvar == 'B')
                    {
                        Zen_Tech.Accessories.Kaiser.Kaiser_Elite_J2000.full_documentationJ2000(Name);
                    }
                    if(Cvar == 'C')
                    {
                        Zen_Tech.Accessories.Kaiser.Kaiser_Elite_J3000.full_documentationJ3000(Name);
                    }
                }
                if(catA == 'D')
                {
                    System.out.println("There are only Three categories for this package.\n1)A for Student use\n2)B for Gaming use\n3)C for Office use");
                    char MKvar = scnr.next().charAt(0);
                    if(MKvar == 'A')
                    {
                        System.out.println("Choose one product:\n1)A for R1000\n2)B for R2000");
                        char MKin = scnr.next().charAt(0);
                        if(MKin == 'A')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Student_Use.Necrolt_Myst_R1000.full_documentationR1000(Name);
                        }
                        if(MKin == 'B')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Student_Use.Necrolt_Myst_R2000.full_documentationR2000(Name);
                        }
                    }
                    if(MKvar == 'B')
                    {
                        System.out.println("Choose one product:\n1)A for F1000\n2)B for F2000");
                        char MKin = scnr.next().charAt(0);
                        if(MKin == 'A')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Gaming_use.Necrolt_Zwift_F1000.full_documentationF1000(Name);
                        }
                        if(MKin == 'B')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Gaming_use.Necrolt_Zwift_F2000.full_documentationF2000(Name);
                        }
                    }
                    if(MKvar == 'C')
                    {
                        System.out.println("Choose one product:\n1)A for G1000\n2)B for G2000");
                        char MKin = scnr.next().charAt(0);
                        if(MKin == 'A')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Office_use.Necrolt_Xlpha_G1000.full_documentationG1000(Name);
                        } 
                        if(MKin == 'B')
                        {
                            Zen_Tech.Accessories.Necrolt.For_Office_use.Necrolt_Xlpha_G2000.full_documentationG2000(Name);
                        }
                    }
                }    
                break;
                default : System.out.println("Please retry, you've selected an invalid option!\nProgram Closed!");
                    
        }
    }  
}