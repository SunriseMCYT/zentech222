package Zen_Tech.Home_Appliances.Lyssarent;


public class LyssarentAboutUS
{
    public static void display()
    {
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
     System.out.println("                                                    Lyssarent");
     System.out.println("* About Our Brand!:");
     System.out.println("* Our motto: Go beyond the Horizon!");
     System.out.println("* Our centre is situated in Denvor.");
     System.out.println("* We offer Effective Dishwasher .");
     System.out.println("* We ensure 24x7 public support.");
     System.out.println("* Our review on trustpilot is 4.7 stars out 5!");
     System.out.println("* Many companies like Bosch, IFB, LG, Whirlpool buy products from us!");
     System.out.println("* We are the best sellers of efficient in the USA !");
     System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
     System.out.println("* Our products have the max speed offered by any other product there.");
     System.out.println("* We have products from a base price of ₹20,000/- to ₹1,00,000/-.");
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
 }
}
