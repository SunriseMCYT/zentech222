package Zen_Tech.Home_Appliances.Lyssarent.Dishwasher;

public class Portable
{
    static double taxE1, totalE1, priceE1;
   public static void DWB535FY(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: DWB535FY");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs:\n Quad Steam Wash\n Dimensions - 50D x 55W x 59.9H\n Capacity - 8 place settings");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This dishwasher has an Inbuilt Heater and Water Comsumption System with Glass Protection System!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayDWB535FY(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 25000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationDWB535FY(String CustomerName1)
   {
       //Call both methods.
       DWB535FY(CustomerName1);
       displayDWB535FY(CustomerName1);
   }
}