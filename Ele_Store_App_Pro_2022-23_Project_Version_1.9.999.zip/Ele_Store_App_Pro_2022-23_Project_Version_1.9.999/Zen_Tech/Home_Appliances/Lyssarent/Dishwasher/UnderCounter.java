package Zen_Tech.Home_Appliances.Lyssarent.Dishwasher;

public class UnderCounter
{
    static double taxE1, totalE1, priceE1;
   public static void DWC646FY(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: DWC646FY");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs:\n Dimensions - 60D x 84.5W x 60H\n Capacity - 13 place settings");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This dishwasher has 4 Wash Programs with High Performance and Effective Cleaning!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayDWC646FY(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 30000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationDWC646FY(String CustomerName1)
   {
       //Call both methods.
       DWC646FY(CustomerName1);
       displayDWC646FY(CustomerName1);
   }
}