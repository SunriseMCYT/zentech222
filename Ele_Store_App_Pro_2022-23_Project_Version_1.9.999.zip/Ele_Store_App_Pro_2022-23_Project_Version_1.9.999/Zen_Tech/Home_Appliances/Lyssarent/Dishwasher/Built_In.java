package Zen_Tech.Home_Appliances.Lyssarent.Dishwasher;

public class Built_In
{
    static double taxE1, totalE1, priceE1;
   public static void DWA424FY(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: DWA424FY");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs:\n Quad Steam Wash\n Dimensions - 23D x 27.7W x 58.1H\n Capacity - 14 place settings");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This dishwasher leaves all the dirty work to steam and cleans the dishes from every angle! It is quiet, Efficient and Reliable with easy loading and maximum flexibility system!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayDWA424FY(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 65000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationDWA424FY(String CustomerName1)
   {
       //Call both methods.
       DWA424FY(CustomerName1);
       displayDWA424FY(CustomerName1);
   }
}
