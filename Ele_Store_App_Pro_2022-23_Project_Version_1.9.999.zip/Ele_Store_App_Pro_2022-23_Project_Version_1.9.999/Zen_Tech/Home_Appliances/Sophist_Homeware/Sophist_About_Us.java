package Zen_Tech.Home_Appliances.Sophist_Homeware;

public class Sophist_About_Us
{
    public static void display()
    {
        System.out.println("* -----------------------------------------------------------------------------------------------------------*");
        System.out.println("                                                    Sophist Homeware");
        System.out.println("* About Our Brand!:");
        System.out.println("* Our motto: Reaching heights beyond the galaxy!");
        System.out.println("* Our centre is situated in New York.");
        System.out.println("* We offer hi-fi tech Microwave.");
        System.out.println("* We ensure 24x7 public support.");
        System.out.println("* Our review on trustpilot is 4.8 stars out 5!");
        System.out.println("* Many companies like LG, Toshiba, Panasonic,Hamilton buy products from us!");
        System.out.println("* We are the most reliable, trustworthy company out there!");
        System.out.println("* Our product has 3 categories like Solo microwave, Grilled microwave and Convection microwave.");
        System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
        System.out.println("* Our products have the max speed offered by any other product there.");
        System.out.println("* We have products from a base price of ₹71,000/- to ₹3,00,000/-.");
        System.out.println("* -----------------------------------------------------------------------------------------------------------*");
    }
}
