package Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave;


public class Sophist_Mr200
{
    static double taxMr2, totalMr2, priceMr2;
   public static void specsMr200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mr200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n ProductType Convection|Grill\n ProductFunctions Baking|Cooking|Defrosting|Grilling|Heating|Toasting\n Capacity30Litres\n InstallationType CounterTop ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 30 Litres Convection Microwave Oven with Barbeque function!");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMr200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMr2 = 250000;
     System.out.println("Base Price: ₹" + priceMr2);
     double taxP1 = (0.15 * priceMr2);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMr2 = taxP1 + priceMr2;
     System.out.println("Total Price: ₹" + totalMr2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMr200(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mr200.specsMr200(CustomerName1);
       Sophist_Mr200.displaypMr200(CustomerName1);
   }
}
