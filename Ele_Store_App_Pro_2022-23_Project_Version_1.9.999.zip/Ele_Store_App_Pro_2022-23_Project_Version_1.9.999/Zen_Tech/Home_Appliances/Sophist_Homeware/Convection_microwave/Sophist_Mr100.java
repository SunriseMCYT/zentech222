package Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave;


public class Sophist_Mr100
{
    static double taxMr1, totalMr1, priceMr1;
   public static void specsMr100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mr100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n ProductType Convection|Grill\n ProductFunctions Baking|Cooking|Defrosting|Grilling|Heating|Toasting\n Capacity30Litres \nInstallationType CounterTop ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 30 Litres Convection Microwave Oven with Barbeque function!");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMr100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMr1 = 250000;
     System.out.println("Base Price: ₹" + priceMr1);
     double taxP1 = (0.15 * priceMr1);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMr1 = taxP1 + priceMr1;
     System.out.println("Total Price: ₹" + totalMr1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMr100(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mr100.specsMr100(CustomerName1);
       Sophist_Mr100.displaypMr100(CustomerName1);
   }
}
