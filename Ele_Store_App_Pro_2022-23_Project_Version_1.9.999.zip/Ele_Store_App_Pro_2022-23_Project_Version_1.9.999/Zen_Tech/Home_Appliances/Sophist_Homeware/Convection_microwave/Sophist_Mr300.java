package Zen_Tech.Home_Appliances.Sophist_Homeware.Convection_microwave;


public class Sophist_Mr300
{
    static double taxMr3, totalMr3, priceMr3;
   public static void specsMr300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mr300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n ProductType Convection|Grill\n ProductFunctions Baking|Cooking|Defrosting|Grilling|Heating|Toasting\n Capacity30Litres\n InstallationType CounterTop ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 30 Litres Convection Microwave Oven with Barbeque function!");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMr300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMr3 = 250000;
     System.out.println("Base Price: ₹" + priceMr3);
     double taxP1 = (0.15 * priceMr3);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMr3 = taxP1 + priceMr3;
     System.out.println("Total Price: ₹" + totalMr3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMr300(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mr300.specsMr300(CustomerName1);
       Sophist_Mr300.displaypMr300(CustomerName1);
   }
}
