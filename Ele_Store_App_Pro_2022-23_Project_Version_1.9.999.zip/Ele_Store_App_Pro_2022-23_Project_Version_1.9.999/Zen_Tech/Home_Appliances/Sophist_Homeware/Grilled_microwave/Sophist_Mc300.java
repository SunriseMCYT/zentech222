package Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave;


public class Sophist_Mc300
{
    static double taxMc3, totalMc3, priceMc3;
   public static void specsMc300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mc300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Product Category OTG\n ProductType Convection | GrillProduct FunctionsBaking | Grilling | Toasting | Roasting\n Capacity60 Litres");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 60 Litres Oven Toaster Griller !");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMc300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMc3 = 250000;
     System.out.println("Base Price: ₹" + priceMc3);
     double taxP1 = (0.15 * priceMc3);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMc3 = taxP1 + priceMc3;
     System.out.println("Total Price: ₹" + totalMc3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMc300(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mc300.specsMc300(CustomerName1);
       Sophist_Mc300.displaypMc300(CustomerName1);
   }
}
