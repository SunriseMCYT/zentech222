package Zen_Tech.Home_Appliances.Sophist_Homeware.Grilled_microwave;


public class Sophist_Mc100
{
    static double taxMc1, totalMc1, priceMc1;
   public static void specsMc100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mc100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Product Category OTG\n ProductType Convection | GrillProduct FunctionsBaking | Grilling | Toasting | Roasting\n Capacity60 Litres");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 60 Litres Oven Toaster Griller !");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMc100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMc1 = 250000;
     System.out.println("Base Price: ₹" + priceMc1);
     double taxP1 = (0.15 * priceMc1);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMc1 = taxP1 + priceMc1;
     System.out.println("Total Price: ₹" + totalMc1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMc100(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mc100.specsMc100(CustomerName1);
       Sophist_Mc100.displaypMc100(CustomerName1);
   }
}
