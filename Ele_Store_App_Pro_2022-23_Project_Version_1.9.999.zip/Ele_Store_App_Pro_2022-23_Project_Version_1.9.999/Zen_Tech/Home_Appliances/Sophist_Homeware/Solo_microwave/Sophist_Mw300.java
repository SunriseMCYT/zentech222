package Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave;


public class Sophist_Mw300
{
    static double taxMw3, totalMw3, priceMw3;
   public static void specsMw300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mw300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n ProductCategory MicrowaveOven\n ProductType Solo\n ProductFunctions Cooking | Defrosting | HeatingCapacity20 Litres\n InstallationType CounterTop ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 20 litres Solo Microwave Oven !");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMw300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMw3 = 250000;
     System.out.println("Base Price: ₹" + priceMw3);
     double taxP1 = (0.15 * priceMw3);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMw3 = taxP1 + priceMw3;
     System.out.println("Total Price: ₹" + totalMw3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMw300(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mw300.specsMw300(CustomerName1);
       Sophist_Mw300.displaypMw300(CustomerName1);
   }
}
