package Zen_Tech.Home_Appliances.Sophist_Homeware.Solo_microwave;


public class Sophist_Mw200
{
    static double taxMw2, totalMw2, priceMw2;
   public static void specsMw200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Mw200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n ProductCategory MicrowaveOven\n ProductType Solo\n ProductFunctions Cooking | Defrosting | HeatingCapacity20 Litres\n InstallationType CounterTop ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Microwave is a 20 litres Solo Microwave Oven !");
     System.out.println("This Microwave is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypMw200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceMw2 = 250000;
     System.out.println("Base Price: ₹" + priceMw2);
     double taxP1 = (0.15 * priceMw2);
     System.out.println("Tax Price: ₹" + taxP1);
     totalMw2 = taxP1 + priceMw2;
     System.out.println("Total Price: ₹" + totalMw2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationMw200(String CustomerName1)
   {
       //Call both methods.
       Sophist_Mw200.specsMw200(CustomerName1);
       Sophist_Mw200.displaypMw200(CustomerName1);
   }
}
