package Zen_Tech.Home_Appliances.Elite_Homeware.LED;

public class LED_50Inches
{
   static double taxE1, totalE1, priceE1;
   public static void E1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: E1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 50.00 inches\n Screen Type - LED\n Dimensions - 1124.8 x 650.2 x 60.2\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV has an brilliant picture and sound quality!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayE1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 100000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationE1000(String CustomerName1)
   {
       //Call both methods.
       E1000(CustomerName1);
       displayE1000(CustomerName1);
   }
}