package Zen_Tech.Home_Appliances.Elite_Homeware.LED;

public class LED_43Inches
{
   static double taxE1, totalE1, priceE1;
   public static void E500(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: E500");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 43.00 inches\n Screen Type - LED\n Connector Type - Wi-Fi,USB,Ethernet,HDMI\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV has an Enhanced Brightness with IPS technology!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayE500(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 50000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationE500(String CustomerName1)
   {
       //Call both methods.
       E500(CustomerName1);
       displayE500(CustomerName1);
   }
}