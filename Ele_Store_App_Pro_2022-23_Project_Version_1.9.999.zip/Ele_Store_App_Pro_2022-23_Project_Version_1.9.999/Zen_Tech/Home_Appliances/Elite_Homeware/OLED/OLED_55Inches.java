package Zen_Tech.Home_Appliances.Elite_Homeware.OLED;

public class OLED_55Inches
{
    static double taxO2, totalO2, priceO2;
   public static void O2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: O2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 55.00 inches\n Screen Type - OLED\n Sound Output - 24W\n Refresh rate - 60Hz\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV has an AI-powered Gamma engine and offers a number of enhancements for a smart and durable TV experience!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayO2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO2 = 150000;
     System.out.println("Base Price: ₹" + priceO2);
     double taxO2 = (0.15 * priceO2);
     System.out.println("Tax Price: ₹" + taxO2);
     totalO2 = taxO2 + priceO2;
     System.out.println("Total Price: ₹" + totalO2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO2000(String CustomerName1)
   {
       //Call both methods.
       O2000(CustomerName1);
       displayO2000(CustomerName1);
   }
}