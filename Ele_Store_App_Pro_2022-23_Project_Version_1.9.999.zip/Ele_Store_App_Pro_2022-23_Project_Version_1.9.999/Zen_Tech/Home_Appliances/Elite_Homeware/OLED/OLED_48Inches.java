package Zen_Tech.Home_Appliances.Elite_Homeware.OLED;

public class OLED_48Inches
{
    static double taxO1, totalO1, priceO1;
   public static void O1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: O1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 48.00 inches\n Screen Type - OLED\n Connector Type - Bluetooth,Wi-Fi,USB,HDMI\n Refresh rate - 60Hz\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV has an AI Processor that uses Foreground and Background Enhancing to maximise the field of depth for outstanding lifelike image quality!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayO1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO1 = 90000;
     System.out.println("Base Price: ₹" + priceO1);
     double taxO1 = (0.15 * priceO1);
     System.out.println("Tax Price: ₹" + taxO1);
     totalO1 = taxO1 + priceO1;
     System.out.println("Total Price: ₹" + totalO1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO1000(String CustomerName1)
   {
       //Call both methods.
       O1000(CustomerName1);
       displayO1000(CustomerName1);
   }
}