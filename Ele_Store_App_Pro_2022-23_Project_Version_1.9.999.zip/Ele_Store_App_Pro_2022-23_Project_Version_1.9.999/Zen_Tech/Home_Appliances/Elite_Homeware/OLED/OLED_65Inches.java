package Zen_Tech.Home_Appliances.Elite_Homeware.OLED;

public class OLED_65Inches
{
    static double taxO3, totalO3, priceO3;
   public static void O3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: O3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 65.00 inches\n Screen Type - OLED\n Connector Type - Bluetooth,Wi-Fi,USB,HDMI\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV Smart Assistance and Convinient Connectivity!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayO3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO3 = 89000;
     System.out.println("Base Price: ₹" + priceO3);
     double taxO3 = (0.15 * priceO3);
     System.out.println("Tax Price: ₹" + taxO3);
     totalO3 = taxO3 + priceO3;
     System.out.println("Total Price: ₹" + totalO3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationO3000(String CustomerName1)
   {
       //Call both methods.
       O3000(CustomerName1);
       displayO3000(CustomerName1);
   }
}