package Zen_Tech.Home_Appliances.Elite_Homeware.QLED;

public class QLED_65Inches
{
    static double taxO1, totalO1, priceO1;
   public static void Q3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model Number: Q3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println(" Specs: Display:\n 65.00 inches\n Screen Type - QLED\n Connector Type - Wi-Fi,USB,HDMI\n Refresh Rate - 60Hz\n Resolution Standard - 4K");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This TV Smart Assistance and Convinient Connectivity!");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   
   public static void displayQ3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceO1 = 179000;
     System.out.println("Base Price: ₹" + priceO1);
     double taxO1 = (0.15 * priceO1);
     System.out.println("Tax Price: ₹" + taxO1);
     totalO1 = taxO1 + priceO1;
     System.out.println("Total Price: ₹" + totalO1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationQ3000(String CustomerName1)
   {
       //Call both methods.
       Q3000(CustomerName1);
       displayQ3000(CustomerName1);
   }
}