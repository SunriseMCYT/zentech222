package Zen_Tech.Home_Appliances.Kenmore.Quad_Door;

public class Kenmore_Space_S300
{
    static double taxS3, totalS3, priceS3;
   public static void specs300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Gross Refrigerator Capacity 677 Litres\n Installation Type Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a 677L Convertible Frost Free Four-Door Refrigerator with Door in Door!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS3 = 250000;
     System.out.println("Base Price: ₹" + priceS3);
     double taxK1 = (0.15 * priceS3);
     System.out.println("Tax Price: ₹" + taxK1);
     totalS3 = taxK1 + priceS3;
     System.out.println("Total Price: ₹" + totalS3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS300(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Space_S300.specs300(CustomerName1);
       Kenmore_Space_S300.displaypS300(CustomerName1);
   }
}
