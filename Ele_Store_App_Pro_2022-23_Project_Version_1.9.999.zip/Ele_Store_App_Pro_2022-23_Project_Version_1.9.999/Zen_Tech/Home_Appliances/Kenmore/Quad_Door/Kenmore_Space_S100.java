package Zen_Tech.Home_Appliances.Kenmore.Quad_Door;


public class Kenmore_Space_S100
{
   public static double taxS1, totalS1, priceS1;
   public static void specsS100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Gross Refrigerator Capacity 677 Litres\n InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a 677L Convertible Frost Free Four-Door Refrigerator with Door in Door!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS1 = 250000;
     System.out.println("Base Price: ₹" + priceS1);
     double taxK1 = (0.15 * priceS1);
     System.out.println("Tax Price: ₹" + taxK1);
     totalS1 = taxK1 + priceS1;
     System.out.println("Total Price: ₹" + totalS1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS100(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Space_S100.specsS100(CustomerName1);
       Kenmore_Space_S100.displaypS100(CustomerName1);
   }
}
