package Zen_Tech.Home_Appliances.Kenmore.Quad_Door;


public class Kenmore_Space_S200
{
    static double taxS12, totalS2, priceS2;
   public static void specsS200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Gross Refrigerator Capacity 677 Litres\n InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a 677L Convertible Frost Free Four-Door Refrigerator with Door in Door!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS2 = 250000;
     System.out.println("Base Price: ₹" + priceS2);
     double taxK1 = (0.15 * priceS2);
     System.out.println("Tax Price: ₹" + taxK1);
     totalS2 = taxK1 + priceS2;
     System.out.println("Total Price: ₹" + totalS2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS200(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Space_S200.specsS200(CustomerName1);
       Kenmore_Space_S200.displaypS200(CustomerName1);
   }
}
