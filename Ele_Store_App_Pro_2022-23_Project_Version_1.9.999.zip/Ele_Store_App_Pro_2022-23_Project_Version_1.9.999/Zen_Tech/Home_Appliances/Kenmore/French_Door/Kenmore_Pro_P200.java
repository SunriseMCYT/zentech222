package Zen_Tech.Home_Appliances.Kenmore.French_Door;
public class Kenmore_Pro_P200
{
   public static double taxP2, totalP2, priceP2;
   public static void specsP200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Side-by-Side Door\n Gross Refrigerator Capacity 694Litres\n  InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a Litres Frost Free Side by Side Refrigerator with Door Cooling Plus Technology!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displayP200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP2 = 250000;
     System.out.println("Base Price: ₹" + priceP2);
     double taxP2 = (0.15 * priceP2);
     System.out.println("Tax Price: ₹" + taxP2);
     totalP2 = taxP2 + priceP2;
     System.out.println("Total Price: ₹" + totalP2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP200(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Pro_P200.specsP200(CustomerName1);
       Kenmore_Pro_P200.displayP200(CustomerName1);
   }
}
