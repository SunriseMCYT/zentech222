package Zen_Tech.Home_Appliances.Kenmore.French_Door;

public class Kenmore_Pro_P300
{
   public static double taxP3, totalP3, priceP3;
   public static void specsP300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Side-by-Side Door\n Gross Refrigerator Capacity 694Litres\n InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a Litres Frost Free Side by Side Refrigerator with Door Cooling Plus Technology!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypP300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP3 = 250000;
     System.out.println("Base Price: ₹" + priceP3);
     double taxP3 = (0.15 * priceP3);
     System.out.println("Tax Price: ₹" + taxP3);
     totalP3 = taxP3 + priceP3;
     System.out.println("Total Price: ₹" + totalP3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP300(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Pro_P300.specsP300(CustomerName1);
       Kenmore_Pro_P300.displaypP300(CustomerName1);
   }
    }

