package Zen_Tech.Home_Appliances.Kenmore.French_Door;


public class Kenmore_Pro_P100
{
   public static double taxP1, totalP1, priceP1;
   public static void specsP100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: P100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Side-by-Side Door\n Gross Refrigerator Capacity 694Litres\n InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a Litres Frost Free Side by Side Refrigerator with Door Cooling Plus Technology!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypP100(String Customer)
   {
       
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceP1 = 250000;
     System.out.println("Base Price: ₹" + priceP1);
     double taxP1 = (0.15 * priceP1);
     System.out.println("Tax Price: ₹" + taxP1);
     totalP1 = taxP1 + priceP1;
     System.out.println("Total Price: ₹" + totalP1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationP100(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Pro_P100.specsP100(CustomerName1);
       Kenmore_Pro_P100.displaypP100(CustomerName1);
   }
}
