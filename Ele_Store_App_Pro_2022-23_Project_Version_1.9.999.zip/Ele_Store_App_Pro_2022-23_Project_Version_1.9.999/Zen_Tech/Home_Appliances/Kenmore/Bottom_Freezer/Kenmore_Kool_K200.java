package Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer;


public class Kenmore_Kool_K200
{
   public static double taxK2, totalK2, priceK2;
   public static void specsK200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: K200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Cooling technology NoFrost\n Product dimensions (H/W/D) 185.9 / 74.7 / 63cm\n Gross capacity, total 442L");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is Intellifresh Pro Inverter Convertible 325 Litres 2 Star Frost Free Bottom Freezer Refrigerator!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypK200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceK2 = 250000;
     System.out.println("Base Price: ₹" + priceK2);
     double taxK2 = (0.15 * priceK2);
     System.out.println("Tax Price: ₹" + taxK2);
     totalK2 = taxK2 + priceK2;
     System.out.println("Total Price: ₹" + totalK2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationK200(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Kool_K200.specsK200(CustomerName1);
       Kenmore_Kool_K200.displaypK200(CustomerName1);
   }
}
