package Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer;


public class Kenmore_Kool_K100
{
   public static double taxK1, totalK1, priceK1;
   public static void specsK100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: K100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Cooling technology NoFrost\n Product dimensions (H/W/D) 185.9 / 74.7 / 63 cm\n Gross capacity, total 442L");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a Intellifresh Pro Inverter Convertible 325 Litres 2 Star Frost Free Bottom Freezer Refrigerator!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypK100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceK1 = 250000;
     System.out.println("Base Price: ₹" + priceK1);
     double taxK1 = (0.15 * priceK1);
     System.out.println("Tax Price: ₹" + taxK1);
     totalK1 = taxK1 + priceK1;
     System.out.println("Total Price: ₹" + totalK1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationK100(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Kool_K100.specsK100(CustomerName1);
       Kenmore_Kool_K100.displaypK100(CustomerName1);
   }
}
