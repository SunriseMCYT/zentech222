package Zen_Tech.Home_Appliances.Kenmore.Bottom_Freezer;

public class Kenmore_Kool_K300
{
   public static double taxK3, totalK3, priceK3;
   public static void specsK300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: K300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Cooling technology NoFrost\n Product dimensions (H/W/D) 185.9 / 74.7 / 63cm\n Gross capacity, total 442L");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is Intellifresh Pro Inverter Convertible 325 Litres 2 Star Frost Free Bottom Freezer Refrigerator!");
     System.out.println("This Fridge is available in Yellow, Sky Blue, Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypK300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceK3 = 250000;
     System.out.println("Base Price: ₹" + priceK3);
     double taxK3 = (0.15 * priceK3);
     System.out.println("Tax Price: ₹" + taxK3);
     totalK3 = taxK3 + priceK3;
     System.out.println("Total Price: ₹" + totalK3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationK300(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Kool_K300.specsK300(CustomerName1);
       Kenmore_Kool_K300.displaypK300(CustomerName1);
   }
}
