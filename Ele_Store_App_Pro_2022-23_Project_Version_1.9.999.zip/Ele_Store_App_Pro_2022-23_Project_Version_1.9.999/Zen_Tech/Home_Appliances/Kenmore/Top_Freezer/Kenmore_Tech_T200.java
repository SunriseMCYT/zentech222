package Zen_Tech.Home_Appliances.Kenmore.Top_Freezer;

public class Kenmore_Tech_T200
{
   public static double taxT2, totalT2, priceT2;
   public static void specsT200(String CustomerName)
   {
     System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Fridge Specs:\n Double Door GrossRefrigeratorCapacity 270Litres\n NetRefrigeratorCapacity 241Litres\n InstallationType Floor Standing");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This Fridge is a 3 Star Frost Free Double Door Refrigerator with Multi Air Flow System!");
     System.out.println("This Fridge is available in Silver, Turquoise, Black and White.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT2 = 250000;
     System.out.println("Base Price: ₹" + priceT2);
     double taxT1 = (0.15 * priceT2);
     System.out.println("Tax Price: ₹" + taxT1);
     totalT2 = taxT1 + priceT2;
     System.out.println("Total Price: ₹" + totalT2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationT200(String CustomerName1)
   {
       //Call both methods.
       Kenmore_Tech_T200.specsT200(CustomerName1);
       Kenmore_Tech_T200.displaypT200(CustomerName1);
   }
}
