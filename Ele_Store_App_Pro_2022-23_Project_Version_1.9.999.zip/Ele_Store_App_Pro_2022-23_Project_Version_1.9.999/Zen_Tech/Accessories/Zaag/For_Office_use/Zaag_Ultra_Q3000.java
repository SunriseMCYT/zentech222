package Zen_Tech.Accessories.Zaag.For_Office_use;
public class Zaag_Ultra_Q3000
{
   static double taxQ3, totalQ3, priceQ3;
   public static void specsQ3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Q3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\n40000 mAh Lithium Polymer Battery,Ideal for Mobile Phones,Tablets AND Laptops\nBuilt-In Short Circuit Protection\nCharging Ports: 3 x USB (Type-C)38 Watts\nCharging Inputs USB Type-C & Micro USB\n26 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThe Powerbank can charge your devices in an instant , almost taking a maximum of 15 minutes\nIt has a sophisticated and antique look to it\nPortable and userfriendly.  ");
     System.out.println("This POWERBANK is available in Copper, Coal Black, Coquelicot");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypQ3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceQ3 = 23000;
     System.out.println("Base Price: ₹" + priceQ3);
     double taxQ3 = (0.15 * priceQ3);
     System.out.println("Tax Price: ₹" + taxQ3);
     totalQ3 = taxQ3 + priceQ3;
     System.out.println("Total Price: ₹" + totalQ3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationQ3000(String CustomerName1)
   {
       //Call both methods.
       Zaag_Ultra_Q3000.specsQ3000(CustomerName1);
       Zaag_Ultra_Q3000.displaypQ3000(CustomerName1);
   }
}



