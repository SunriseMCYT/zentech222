package Zen_Tech.Accessories.Zaag.For_Office_use;
public class Zaag_Ultra_Q1000
{
   static double taxQ1, totalQ1, priceQ1;
   public static void specsQ1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Q1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\n10000 mAh Lithium Polymer Battery,Ideal for Mobile Phones and Tablets\nBuilt-In Short Circuit Protection\nCharging Ports: 2 x USB (Type-A)10 Watts\nCharging Inputs USB Type-A & Micro USB\n18 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis powerbank is good for travellers.\nThis powerbank is good for travelling purposes and can easily charge your device under 40 minutes."
     + "\n(Depends on usage)\nIt is portable and user-friendly");
     System.out.println("This POWERBANK is available in Neon Green, Orchid, Pansy Purple, Darkrai Black Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypQ1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceQ1 = 5500;
     System.out.println("Base Price: ₹" + priceQ1);
     double taxQ1 = (0.15 * priceQ1);
     System.out.println("Tax Price: ₹" + taxQ1);
     totalQ1 = taxQ1 + priceQ1;
     System.out.println("Total Price: ₹" + totalQ1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationQ1000(String CustomerName1)
   {
       //Call both methods.
       Zaag_Ultra_Q1000.specsQ1000(CustomerName1);
       Zaag_Ultra_Q1000.displaypQ1000(CustomerName1);
   }
}
