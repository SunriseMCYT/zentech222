package Zen_Tech.Accessories.Zaag.For_Office_use;
public class Zaag_Ultra_Q2000
{
   static double taxQ2, totalQ2, priceQ2;
   public static void specsQ2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: Q2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\n20000 mAh Lithium Polymer Battery Ideal for Mobile Phones and Tablets\nBuilt-In Short Circuit Protection\nCharging Ports: 2 x USB (Type-B)30 Watts\nCharging Inputs USB Type-B & Micro USB\n24 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis powerbank has a futuristic and modern look to it. It provides many more benefits than the Q2000 model and is also portable, user-friendly. ");
     System.out.println("This POWERBANK is available in Carribbean Green, Canary, Carmine Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypQ2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceQ2 = 15000;
     System.out.println("Base Price: ₹" + priceQ2);
     double taxQ2 = (0.15 * priceQ2);
     System.out.println("Tax Price: ₹" + taxQ2);
     totalQ2 = taxQ2 + priceQ2;
     System.out.println("Total Price: ₹" + totalQ2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationQ2000(String CustomerName1)
   {
       //Call both methods.
       Zaag_Ultra_Q2000.specsQ2000(CustomerName1);
       Zaag_Ultra_Q2000.displaypQ2000(CustomerName1);
   }
}
