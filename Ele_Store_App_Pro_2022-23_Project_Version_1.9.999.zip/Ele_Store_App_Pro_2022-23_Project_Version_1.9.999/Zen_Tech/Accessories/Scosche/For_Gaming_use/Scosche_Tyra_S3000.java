package Zen_Tech.Accessories.Scosche.For_Gaming_use;

public class Scosche_Tyra_S3000
{
   static double taxS3, totalS3, priceS3;
   public static void specsS3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: On Ear, Connectivity: Bluetooth, Version 5.0\nBattery Life: 80 Hours Playback, Noise Cancellation\nUSP: Wireless Charging, Multifunction Controls\nWarranty: 12 Months");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThe Headset has peak audio quality and and has an antique and ancient look to it.");
     System.out.println("This headset is available in .");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS3 = 41000;
     System.out.println("Base Price: ₹" + priceS3);
     double taxS3 = (0.15 * priceS3);
     System.out.println("Tax Price: ₹" + taxS3);
     totalS3 = taxS3 + priceS3;
     System.out.println("Total Price: ₹" + totalS3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS3000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Tyra_S3000.specsS3000(CustomerName1);
       Scosche_Tyra_S3000.displaypS3000(CustomerName1);
   }
}

