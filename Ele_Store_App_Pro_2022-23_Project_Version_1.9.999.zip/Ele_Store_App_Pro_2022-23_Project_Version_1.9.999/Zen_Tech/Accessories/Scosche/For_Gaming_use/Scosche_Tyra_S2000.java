package Zen_Tech.Accessories.Scosche.For_Gaming_use;


public class Scosche_Tyra_S2000
{
   static double taxS2, totalS2, priceS2;
   public static void specsS2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: Over Ear\nConnectivity: Bluetooth, Version 5.0\nBattery Life: 30 Hours Playback\nFast Charging, Active Noise Cancellation, Voice Assistant: Google\nUSP: Dynamic Bass, Smart Control App\nWarranty: 24 Months");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThe headset gives peak audio quality and has a sophisticated and modernised look to it . ");
     System.out.println("This headset is available in Shadow, Shimmering Blush, Sizzling Sunrise Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS2 = 30000;
     System.out.println("Base Price: ₹" + priceS2);
     double taxS2 = (0.15 * priceS2);
     System.out.println("Tax Price: ₹" + taxS2);
     totalS2 = taxS2 + priceS2;
     System.out.println("Total Price: ₹" + totalS2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS2000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Tyra_S2000.specsS2000(CustomerName1);
       Scosche_Tyra_S2000.displaypS2000(CustomerName1);
   }
}
