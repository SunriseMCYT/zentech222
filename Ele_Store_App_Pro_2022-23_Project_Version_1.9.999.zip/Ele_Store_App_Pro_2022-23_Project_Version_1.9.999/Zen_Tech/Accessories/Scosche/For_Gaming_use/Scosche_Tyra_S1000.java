package Zen_Tech.Accessories.Scosche.For_Gaming_use;


public class Scosche_Tyra_S1000
{
   static double taxS1, totalS1, priceS1;
   public static void specsS1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: Over-Ear\nHyperClear Cardioid Microphone\nConnector Type: USB\nTriforce Titanium 50mm Drivers\nHybrid Fabric and Leatherette Memory Foam Cushion\nWarranty: 12 Months");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nFuturistic headsets with various features which gives the feeling of being in an another world.");
     System.out.println("This headset is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS1 = 17000;
     System.out.println("Base Price: ₹" + priceS1);
     double taxS1 = (0.15 * priceS1);
     System.out.println("Tax Price: ₹" + taxS1);
     totalS1 = taxS1 + priceS1;
     System.out.println("Total Price: ₹" + totalS1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS1000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Tyra_S1000.specsS1000(CustomerName1);
       Scosche_Tyra_S1000.displaypS1000(CustomerName1);
   }
}
