package Zen_Tech.Accessories.Scosche;
public class Scosche_About_us
{
    public static void display()
    {
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
     System.out.println("                                                    Scosche.lim");
     System.out.println("* About Our Brand!:");
     System.out.println("* Our motto: Better Best Fastest");
     System.out.println("* Our centre is situated in India.");
     System.out.println("* We offer hi-fi tech headset.");
     System.out.println("* We ensure 24x7 public and customer support.");
     System.out.println("* Our review on trustpilot is 4.75 stars out 5!");
     System.out.println("* Many companies like Microsoft, Apple, Samsung, Nokia, Facebook and Whatsapp buy products from us!");
     System.out.println("* We are the most reliable, trustworthy company out there!");
     System.out.println("* Our product has 2 categories For gaming and student use.");
     System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
     System.out.println("* Our products have the max audio quality offered by any other product there.");
     System.out.println("* We have products from a base price of ₹3,999/- to ₹45,999/-.");
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
 }
}
