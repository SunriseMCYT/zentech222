package Zen_Tech.Accessories.Scosche.For_Student_use;


public class Scosche_Austra_T3000
{
   static double taxT3, totalT3, priceT3;
   public static void specsT3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: On Ear, Connectivity: Bluetooth, Version 5.0\nBattery Life: 35 Hours Playback, Fast Charging, Noise Cancellation and Noise Isolation\nVoice Assistant: Siri\nUSP: Swivel Ear Cups, 30mm Driver\nWarranty: 12 Months");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThe Headset has an antique and ancient look to it helping to focus more with automatic binaural music.");
     System.out.println("This headset is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT3 = 40000;
     System.out.println("Base Price: ₹" + priceT3);
     double taxT3 = (0.15 * priceT3);
     System.out.println("Tax Price: ₹" + taxT3);
     totalT3 = taxT3 + priceT3;
     System.out.println("Total Price: ₹" + totalT3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationT3000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Austra_T3000.specsT3000(CustomerName1);
       Scosche_Austra_T3000.displaypT3000(CustomerName1);
   }
}
