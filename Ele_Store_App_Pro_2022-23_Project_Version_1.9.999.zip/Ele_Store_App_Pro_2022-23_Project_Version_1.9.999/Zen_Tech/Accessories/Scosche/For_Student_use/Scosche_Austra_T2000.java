package Zen_Tech.Accessories.Scosche.For_Student_use;


public class Scosche_Austra_T2000
{
   static double taxT2, totalT2, priceT2;
   public static void specsT2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: Over Ear, Connectivity: Bluetooth, Version 5.0\nBattery Life: 50 Hours Playback, Fast Charging,Voice Assistant: Google\nUSP: Pure Bass Sound, 40mm Dynamic Driver\nWarranty: 12 Months ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis Headset gives a sophisticated feeling to the user and has higher audio quality");
     System.out.println("This headset is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT2 = 30000;
     System.out.println("Base Price: ₹" + priceT2);
     double taxT2 = (0.15 * priceT2);
     System.out.println("Tax Price: ₹" + taxT2);
     totalT2 = taxT2 + priceT2;
     System.out.println("Total Price: ₹" + totalT2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationT2000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Austra_T2000.specsT2000(CustomerName1);
       Scosche_Austra_T2000.displaypT2000(CustomerName1);
   }
}
