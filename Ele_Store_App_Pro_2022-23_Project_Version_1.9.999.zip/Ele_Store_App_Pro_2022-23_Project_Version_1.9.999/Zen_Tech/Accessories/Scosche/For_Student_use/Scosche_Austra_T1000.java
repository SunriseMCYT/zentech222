package Zen_Tech.Accessories.Scosche.For_Student_use;


public class Scosche_Austra_T1000
{
   static double taxT1, totalT1, priceT1;
   public static void specsT1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: T1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nOrientation Type: Over Ear, With Mic,Connector Type: Wired\n3.5mm, USP: 50mm Dynamic Driver, Active Noise Cancellation\nWarranty: 12 Months ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nA headset good for focusing with active noise cancellation, has a mic for interaction.");
     System.out.println("This headset is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypT1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceT1 = 15000;
     System.out.println("Base Price: ₹" + priceT1);
     double taxT1 = (0.15 * priceT1);
     System.out.println("Tax Price: ₹" + taxT1);
     totalT1 = taxT1 + priceT1;
     System.out.println("Total Price: ₹" + totalT1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationT1000(String CustomerName1)
   {
       //Call both methods.
       Scosche_Austra_T1000.specsT1000(CustomerName1);
       Scosche_Austra_T1000.displaypT1000(CustomerName1);
   }
}
