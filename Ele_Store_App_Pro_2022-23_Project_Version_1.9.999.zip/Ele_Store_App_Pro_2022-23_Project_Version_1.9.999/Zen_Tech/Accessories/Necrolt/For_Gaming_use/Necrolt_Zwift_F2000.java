package Zen_Tech.Accessories.Necrolt.For_Gaming_use;


public class Necrolt_Zwift_F2000
{
   static double taxF2, totalF2, priceF2;
   public static void specsF2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: F2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nFor Gaming, Ideal For: Desktops and Laptops\nConnection Type: Wired, 3 LED Color Light, 19 Anti-ghost Keys\n12 Months Warranty ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis Gaming Keyboard brings you to the peak gaming ability with absolute no noise coming from pressing the keys\nIts built-in processor functions magnificiently.");
     System.out.println("This KEYBOARD is available in Russian Violet, Scarlet, Sea Blue Colours..");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypF2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceF2 = 28000;
     System.out.println("Base Price: ₹" + priceF2);
     double taxF2 = (0.15 * priceF2);
     System.out.println("Tax Price: ₹" + taxF2);
     totalF2 = taxF2 + priceF2;
     System.out.println("Total Price: ₹" + totalF2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationF2000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Zwift_F2000.specsF2000(CustomerName1);
       Necrolt_Zwift_F2000.displaypF2000(CustomerName1);
   }
}
