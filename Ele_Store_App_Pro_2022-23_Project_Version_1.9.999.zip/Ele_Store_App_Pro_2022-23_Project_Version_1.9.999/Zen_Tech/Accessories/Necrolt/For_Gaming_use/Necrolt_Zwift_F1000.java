package Zen_Tech.Accessories.Necrolt.For_Gaming_use;
public class Necrolt_Zwift_F1000
{
   static double taxF1, totalF1, priceF1;
   public static void specsF1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: F1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nFor Gaming, 1.2m Braided Cable\nDPI: 800/1600/2400/3200\nCompatible with Windows XP and above, 8 Programmable Keys with LED Lighting and Scroll Button\n1 Year Manufacturer Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nA Gaming mouse compatible for all gamers with autoclicking enabled\nIt grants you the ultimate experience into the game you are playing\nIt has ambidextrous features and grants you the peak gaming ability.");
     System.out.println("This mouse is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypF1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceF1 = 9000;
     System.out.println("Base Price: ₹" + priceF1);
     double taxF1 = (0.15 * priceF1);
     System.out.println("Tax Price: ₹" + taxF1);
     totalF1 = taxF1 + priceF1;
     System.out.println("Total Price: ₹" + totalF1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationF1000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Zwift_F1000.specsF1000(CustomerName1);
       Necrolt_Zwift_F1000.displaypF1000(CustomerName1);
   }
}
