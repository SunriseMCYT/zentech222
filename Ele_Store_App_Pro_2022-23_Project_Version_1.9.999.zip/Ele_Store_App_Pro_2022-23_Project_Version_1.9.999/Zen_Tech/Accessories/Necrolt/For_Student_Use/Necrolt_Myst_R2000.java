package Zen_Tech.Accessories.Necrolt.For_Student_Use;
public class Necrolt_Myst_R2000
{
   static double taxR2, totalR2, priceR2;
   public static void specsR2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nKeyboard, Ideal for Desktops and Laptops,Connection Type: Wireless\nHot Keys Functions,109 Keys & 12 Working Function Keys\n12 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis keyboard has a futuristic and sophisticated look to it, with its processor having no delay and working magnigiciently.");
     System.out.println("This device is available in Submarine Grey, Aquamrine Cyan, Maroon");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR2 = 27000;
     System.out.println("Base Price: ₹" + priceR2);
     double taxR2 = (0.15 * priceR2);
     System.out.println("Tax Price: ₹" + taxR2);
     totalR2 = taxR2 + priceR2;
     System.out.println("Total Price: ₹" + totalR2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR2000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Myst_R2000.specsR2000(CustomerName1);
       Necrolt_Myst_R2000.displaypR2000(CustomerName1);
   }
}
