package Zen_Tech.Accessories.Necrolt.For_Student_Use;
public class Necrolt_Myst_R1000
{
   static double taxR1, totalR1, priceR1;
   public static void specsR1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nMouse, Ideal for Desktops and Laptops\nConnection Type: Wireless, 1600 DPI Resolution, 2.4 GHz Wireless Connection\n11 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThis Ambidextrous mouse is extremely good for usage with various benifits.");
     System.out.println("This device is available in Jet Black, Aquamrine Blue, Vermilion Red Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR1 = 12000;
     System.out.println("Base Price: ₹" + priceR1);
     double taxR1 = (0.15 * priceR1);
     System.out.println("Tax Price: ₹" + taxR1);
     totalR1 = taxR1 + priceR1;
     System.out.println("Total Price: ₹" + totalR1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR1000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Myst_R1000.specsR1000(CustomerName1);
       Necrolt_Myst_R1000.displaypR1000(CustomerName1);
   }
}
