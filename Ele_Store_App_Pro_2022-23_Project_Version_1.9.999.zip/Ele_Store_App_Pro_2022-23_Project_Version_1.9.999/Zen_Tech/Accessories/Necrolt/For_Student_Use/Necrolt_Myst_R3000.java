package Zen_Tech.Accessories.Necrolt.For_Student_Use;


public class Necrolt_Myst_R3000
{
   static double taxR3, totalR3, priceR3;
   public static void specsR3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nEthernet Connection, Functions: Router,3 Mbps Transmission Rate\n12 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nThe Wifi-router has a good transmission rate of 3 mbps, and can be connected to any device\nIt has an antique look to it\nIt is Portable and User-Friendly.");
     System.out.println("This device is available in Crystal white, Scarlet Red, Iron Rust, Royal Gold");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR3 = 36000;
     System.out.println("Base Price: ₹" + priceR3);
     double taxR3 = (0.15 * priceR3);
     System.out.println("Tax Price: ₹" + taxR3);
     totalR3 = taxR3 + priceR3;
     System.out.println("Total Price: ₹" + totalR3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR3000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Myst_R3000.specsR3000(CustomerName1);
       Necrolt_Myst_R3000.displaypR3000(CustomerName1);
   }
}