package Zen_Tech.Accessories.Necrolt.For_Office_use;


public class Necrolt_Xlpha_G1000
{
   static double taxG1, totalG1, priceG1;
   public static void specsG1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: G1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nFor Office use, 1.5m Braided Cable\nDPI: 800/1600/2400/3200/6400, Compatible with Windows XP and above\n12 Programmable Keys with LED Lighting and Scroll Button\n1.8 Year Manufacturer Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nAn Office mouse compatible for all devices. Noise-free and adjustable settings. Various features with auto-scroll button.");
     System.out.println("This mouse is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypG1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceG1 = 20000;
     System.out.println("Base Price: ₹" + priceG1);
     double taxG1 = (0.15 * priceG1);
     System.out.println("Tax Price: ₹" + taxG1);
     totalG1 = taxG1 + priceG1;
     System.out.println("Total Price: ₹" + totalG1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationG1000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Xlpha_G1000.specsG1000(CustomerName1);
       Necrolt_Xlpha_G1000.displaypG1000(CustomerName1);
   }
}
