package Zen_Tech.Accessories.Necrolt.For_Office_use;


public class Necrolt_Xlpha_G2000
{
   static double taxG2, totalG2, priceG2;
   public static void specsG2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: G2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nKeyboard , Ideal for Laptop | Desktop | Tablet | iPad and Smart TV\nConnection Type: Wireless, Retro Typewriter Flexible Keys\n2.4 GHz Dropout Free Connection\n12 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nKeyboard compatible for office use with a futuristic, sophisticated, and modernised look. It has a number of features.");
     System.out.println("This KEYBOARD is available in Shadow, Shimmering Blush, Sizzling Sunrise Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypG2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceG2 = 26000;
     System.out.println("Base Price: ₹" + priceG2);
     double taxG2 = (0.15 * priceG2);
     System.out.println("Tax Price: ₹" + taxG2);
     totalG2 = taxG2 + priceG2;
     System.out.println("Total Price: ₹" + totalG2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationG2000(String CustomerName1)
   {
       //Call both methods.
       Necrolt_Xlpha_G2000.specsG2000(CustomerName1);
       Necrolt_Xlpha_G2000.displaypG2000(CustomerName1);
   }
}
