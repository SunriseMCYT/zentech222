package Zen_Tech.Accessories.Kaiser;


public class Kaiser_Elite_J1000
{
   static double taxJ1, totalJ1, priceJ1;
   public static void specsJ1000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: J1000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nWall Charging Adapter with Cable\nIdeal For: Mobiles, Tablets / eReaders\n1 x Micro USB Charging Output, Fast Charging Capability, BIS Certified\n6 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:Built-in with fast charging processor, capable of charging a device under 60 minutes.");
     System.out.println("This Charger is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypJ1000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceJ1 = 18000;
     System.out.println("Base Price: ₹" + priceJ1);
     double taxJ1 = (0.15 * priceJ1);
     System.out.println("Tax Price: ₹" + taxJ1);
     totalJ1 = taxJ1 + priceJ1;
     System.out.println("Total Price: ₹" + totalJ1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationJ1000(String CustomerName1)
   {
       //Call both methods.
       Kaiser_Elite_J1000.specsJ1000(CustomerName1);
       Kaiser_Elite_J1000.displaypJ1000(CustomerName1);
   }
}
