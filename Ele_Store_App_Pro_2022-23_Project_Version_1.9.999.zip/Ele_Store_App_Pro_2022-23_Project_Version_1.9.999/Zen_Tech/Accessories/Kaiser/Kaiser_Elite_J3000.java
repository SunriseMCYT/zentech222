package Zen_Tech.Accessories.Kaiser;



public class Kaiser_Elite_J3000
{
   static double taxJ3, totalJ3, priceJ3;
   public static void specsJ3000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: J3000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nWall Charging Adapter\nIdeal For: Mobile, Qualcomm Certified, Fast Charging Capability, Universal Compatibility\n24 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nQuick charging with 3.0 technology, can charge only smartphones under 1/4 of a hour\nAutomatically stops the transmission of power when battery reaches 100% to avoid damage.");
     System.out.println("This Charger is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypJ3000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceJ3 = 43000;
     System.out.println("Base Price: ₹" + priceJ3);
     double taxJ3 = (0.15 * priceJ3);
     System.out.println("Tax Price: ₹" + taxJ3);
     totalJ3 = taxJ3 + priceJ3;
     System.out.println("Total Price: ₹" + totalJ3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationJ3000(String CustomerName1)
   {
       //Call both methods.
       Kaiser_Elite_J3000.specsJ3000(CustomerName1);
       Kaiser_Elite_J3000.displaypJ3000(CustomerName1);
   }
}
