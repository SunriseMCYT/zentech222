package Zen_Tech.Accessories.Kaiser;


public class Kaiser_Elite_J2000
{
   static double taxJ2, totalJ2, priceJ2;
   public static void specsJ2000(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: J2000");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("SPECS:\nWall Charging Adapter with Cable\nIdeal For: Mobiles and Tablets\nBIS Certified, Fast Charging Capability, Multi Protection\n6 Months Warranty");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("OVERVIEW:\nHyper-charger with dual protection, capable of charging any device under 30 minutes with 27 watts.");
     System.out.println("This Charger is available in Raspberry Rose, Rojo Spanish Red,Rosso Corsa Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypJ2000(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceJ2 = 35000;
     System.out.println("Base Price: ₹" + priceJ2);
     double taxJ2 = (0.15 * priceJ2);
     System.out.println("Tax Price: ₹" + taxJ2);
     totalJ2 = taxJ2 + priceJ2;
     System.out.println("Total Price: ₹" + totalJ2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationJ2000(String CustomerName1)
   {
       //Call both methods.
       Kaiser_Elite_J2000.specsJ2000(CustomerName1);
       Kaiser_Elite_J2000.displaypJ2000(CustomerName1);
   }
}
