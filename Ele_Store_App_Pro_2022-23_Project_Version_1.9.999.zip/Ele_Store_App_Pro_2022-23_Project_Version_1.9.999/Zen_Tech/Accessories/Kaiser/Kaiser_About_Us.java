package Zen_Tech.Accessories.Kaiser;
public class Kaiser_About_Us
{
    public static void display()
    {
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
     System.out.println("                                                    Kaiser");
     System.out.println("* About Our Brand!:");
     System.out.println("* Our motto: Become Better than the Best!");
     System.out.println("* Our centre is situated in India.");
     System.out.println("* We offer hi-fi tech Chargers.");
     System.out.println("* We ensure 24x7 public and customer support.");
     System.out.println("* Our review on trustpilot is 4.5 stars out 5!");
     System.out.println("* Many companies like Microsoft, Apple, Samsung, Nokia, Facebook and Whatsapp buy products from us!");
     System.out.println("* We are the most reliable, trustworthy company out there!");
     System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
     System.out.println("* Our products have the max speed offered by any other product there.");
     System.out.println("* We have products from a base price of ₹4,000/- to ₹50,000/-.");
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
 }
}
