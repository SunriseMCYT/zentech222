package Zen_Tech.Laptops.Phoenix.For_Gaming_Use;
public class Phoenix_Rise_R300
{
   static double taxR3, totalR3, priceR3;
   public static void specsR300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: AMD Ryzen Threadripper PRO 3975WX\nRAM: 1 TB\nSSD: 20 PB\nGPU:NVIDIA TITAN V x 10 12Gb x 10");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Military look with 360 degree foldable screen! It has a 32k face camera! This laptop has a 48 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Steel Grey, Arsenopyrite White, Burnt Sienna Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR3 = 1800000;
     System.out.println("Base Price: ₹" + priceR3);
     double taxR2 = (0.10 * priceR3);
     System.out.println("Tax Price: ₹" + taxR2);
     totalR3 = taxR2 + priceR3;
     System.out.println("Total Price: ₹" + totalR3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR300(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Rise_R300.specsR300(CustomerName1);
       Phoenix_Rise_R300.displaypR300(CustomerName1);
   }
}
