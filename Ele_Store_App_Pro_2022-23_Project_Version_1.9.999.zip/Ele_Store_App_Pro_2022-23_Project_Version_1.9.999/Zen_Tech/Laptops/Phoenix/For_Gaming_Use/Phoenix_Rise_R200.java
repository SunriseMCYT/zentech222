package Zen_Tech.Laptops.Phoenix.For_Gaming_Use;
public class Phoenix_Rise_R200
{
   static double taxR2, totalR2, priceR2;
   public static void specsR200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: AMD Ryzen Threadripper PRO 3945WX 4.3 GHz\nRAM: 64 GB\nSSD: 2 PB\nGPU: NVIDIA RTX 4090 Ti 48Gb x 32");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an stylish look with 360 degree foldable screen! It has a 16k face camera! This laptop has a 24 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Military Green, Vermilion, Teal Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR2 = 1300000;
     System.out.println("Base Price: ₹" + priceR2);
     double taxR2 = (0.10 * priceR2);
     System.out.println("Tax Price: ₹" + taxR2);
     totalR2 = taxR2 + priceR2;
     System.out.println("Total Price: ₹" + totalR2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR200(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Rise_R200.specsR200(CustomerName1);
       Phoenix_Rise_R200.displaypR200(CustomerName1);
   }
}
