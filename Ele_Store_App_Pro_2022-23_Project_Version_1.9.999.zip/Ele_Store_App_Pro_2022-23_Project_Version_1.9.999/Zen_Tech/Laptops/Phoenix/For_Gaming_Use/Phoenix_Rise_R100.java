package Zen_Tech.Laptops.Phoenix.For_Gaming_Use;
public class Phoenix_Rise_R100
{
   static double taxR1, totalR1, priceR1;
   public static void specsR100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: R100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU:  AMD Ryzen Threadripper Pro 5995WX 4.5 GHz\nRAM: 32 GB\nSSD: 1 PB\nGPU: NVIDIA RTX 4090 Ti 48Gb x 16");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an dynamic look with 180 degree foldable screen! It has a 8k face camera! This laptop has a 15 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Ruby Red, Citrine Yellow, Sapphire Blue, Lonsedalite Grey Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypR100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceR1 = 900000;
     System.out.println("Base Price: ₹" + priceR1);
     double taxR1 = (0.10 * priceR1);
     System.out.println("Tax Price: ₹" + taxR1);
     totalR1 = taxR1 + priceR1;
     System.out.println("Total Price: ₹" + totalR1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationR100(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Rise_R100.specsR100(CustomerName1);
       Phoenix_Rise_R100.displaypR100(CustomerName1);
   }
}
