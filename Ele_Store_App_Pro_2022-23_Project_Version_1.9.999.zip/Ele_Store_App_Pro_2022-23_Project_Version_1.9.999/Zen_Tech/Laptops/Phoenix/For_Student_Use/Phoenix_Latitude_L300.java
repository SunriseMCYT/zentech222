package Zen_Tech.Laptops.Phoenix.For_Student_Use;
public class Phoenix_Latitude_L300
{
   static double taxL3, totalL3, priceL3;
   public static void specsL300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: L300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i3 12100 4.3 GHz\nRAM: 64 GB\nSSD: 50 TB\nGPU: NVIDIA GTX GeForce 1650 Super 4 GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Stylish look with 360 degree foldable screen! It has a 16k face camera! This laptop has a 48 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Azure, Pink, Yellow Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypL300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceL3 = 800000;
     System.out.println("Base Price: ₹" + priceL3);
     double taxL3 = (0.15 * priceL3);
     System.out.println("Tax Price: ₹" + taxL3);
     totalL3 = taxL3 + priceL3;
     System.out.println("Total Price: ₹" + totalL3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationL300(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Latitude_L300.specsL300(CustomerName1);
       Phoenix_Latitude_L300.displaypL300(CustomerName1);
   }
}
