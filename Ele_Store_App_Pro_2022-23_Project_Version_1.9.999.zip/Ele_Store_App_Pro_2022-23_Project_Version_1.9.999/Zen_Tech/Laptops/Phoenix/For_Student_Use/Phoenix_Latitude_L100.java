package Zen_Tech.Laptops.Phoenix.For_Student_Use;
public class Phoenix_Latitude_L100
{
   static double taxL1, totalL1, priceL1;
   public static void specsL100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: L100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i9 13900k 13th gen 5.80 GHz\nRAM: 16 GB\nSSD: 10 TB\nGPU: NVIDIA RTX 4090 Ti 48Gb x 5");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Sleek look with 180 degree foldable screen! It has a 1080p face camera! This laptop has a 12 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Plum, Turquoise, Coral Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypL100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceL1 = 575000;
     System.out.println("Base Price: ₹" + priceL1);
     double taxL1 = (0.15 * priceL1);
     System.out.println("Tax Price: ₹" + taxL1);
     totalL1 = taxL1 + priceL1;
     System.out.println("Total Price: ₹" + totalL1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationL100(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Latitude_L100.specsL100(CustomerName1);
       Phoenix_Latitude_L100.displaypL100(CustomerName1);
   }
}
