package Zen_Tech.Laptops.Phoenix.For_Student_Use;
public class Phoenix_Latitude_L200
{
   static double taxL2, totalL2, priceL2;
   public static void specsL200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: L200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i3 1215U 4.40 GHz\nRAM: 32 GB\nSSD: 20 TB\nGPU: NVIDIA GTX GeForce 1660 Ti 6 GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Sleek look with 180 degree foldable screen! It has a 4k face camera! This laptop has a 18 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Grey, Bronze, Peach Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypL200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceL2 = 600000;
     System.out.println("Base Price: ₹" + priceL2);
     double taxL2 = (0.15 * priceL2);
     System.out.println("Tax Price: ₹" + taxL2);
     totalL2 = taxL2 + priceL2;
     System.out.println("Total Price: ₹" + totalL2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationL200(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Latitude_L200.specsL200(CustomerName1);
       Phoenix_Latitude_L200.displaypL200(CustomerName1);
   }
}
