package Zen_Tech.Laptops.Phoenix.For_Office_Use;
public class Phoenix_Excellence_E200
{
   static double taxE2, totalE2, priceE2;
   public static void specsE200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: E200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i7 13700k 13th gen 5.30 GHz\nRAM: 64 GB\nSSD: 10 TB\nGPU: NVIDIA RTX 4060 10Gb x 2");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an insane office look with 360 degree foldable screen! It has a 4k face camera! This laptop has a 12 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Mountain White, Coal Black Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypE200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE2 = 1000000;
     System.out.println("Base Price: ₹" + priceE2);
     double taxE2 = (0.15 * priceE2);
     System.out.println("Tax Price: ₹" + taxE2);
     totalE2 = taxE2 + priceE2;
     System.out.println("Total Price: ₹" + totalE2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationE200(String CustomerName2)
   {
       //Call both methods.
       Phoenix_Excellence_E200.specsE200(CustomerName2);
       Phoenix_Excellence_E200.displaypE200(CustomerName2);
   }
}
