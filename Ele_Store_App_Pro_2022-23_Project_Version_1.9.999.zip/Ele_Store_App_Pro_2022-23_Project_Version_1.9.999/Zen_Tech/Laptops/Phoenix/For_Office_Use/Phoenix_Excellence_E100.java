package Zen_Tech.Laptops.Phoenix.For_Office_Use;
public class Phoenix_Excellence_E100
{
   static double taxE1, totalE1, priceE1;
   public static void specsE100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: E100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i9 13900k 13th gen 5.80 GHz\nRAM: 64 GB\nSSD: 10 TB\nGPU: NVIDIA RTX 4090 Ti 48Gb x 5");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an crazy office look with 360 degree foldable screen! It has a 4k face camera! This laptop has a 12 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Mountain White, Coal Black Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypE100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceE1 = 1000000;
     System.out.println("Base Price: ₹" + priceE1);
     double taxE1 = (0.15 * priceE1);
     System.out.println("Tax Price: ₹" + taxE1);
     totalE1 = taxE1 + priceE1;
     System.out.println("Total Price: ₹" + totalE1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationE100(String CustomerName1)
   {
       //Call both methods.
       Phoenix_Excellence_E100.specsE100(CustomerName1);
       Phoenix_Excellence_E100.displaypE100(CustomerName1);
   }
}
