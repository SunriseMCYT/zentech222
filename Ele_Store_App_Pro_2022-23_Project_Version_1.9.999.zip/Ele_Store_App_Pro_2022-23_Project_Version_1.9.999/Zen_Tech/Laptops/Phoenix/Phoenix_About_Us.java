package Zen_Tech.Laptops.Phoenix;
public class Phoenix_About_Us
{
    public static void display()
    {
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
     System.out.println("                                                    Phoenix");
     System.out.println("* About Our Brand!:");
     System.out.println("* Our motto: Go beyond the Horizon!");
     System.out.println("* Our centre is situated in Seattle.");
     System.out.println("* We offer Modern Office Tech laptops, Gaming And Student Laptops.");
     System.out.println("* We ensure 24x7 public support.");
     System.out.println("* Our review on trustpilot is 4.5 stars out 5!");
     System.out.println("* Many companies like Microsoft, Apple, Samsung, Nokia, Facebook and Whatsapp buy products from us!");
     System.out.println("* We are the most supreme office laptop company out there!");
     System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
     System.out.println("* Our products have the max speed offered by any other product there.");
     System.out.println("* We have products from a base price of ₹5,75,000/- to ₹20,00,000/-.");
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
 }
}

