package Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use;
public class Galaxy_Vision_V200
{
   static double taxV2, totalV2, priceV2;
   public static void specsV200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel i3 2120 2nd Gen 3.3 GHz\nRAM: 4 GB\nSSD: 2 TB\nGPU: Intel UHD Graphics 620 2GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Thin And Retro look! It has a 1080p face camera! This laptop has 6 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in White and Black Colour.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV2 = 100000;
     System.out.println("Base Price: ₹" + priceV2);
     double taxV2 = (0.15 * priceV2);
     System.out.println("Tax Price: ₹" + taxV2);
     totalV2 = taxV2 + priceV2;
     System.out.println("Total Price: ₹" + totalV2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV200(String CustomerName2)
   {
       //Call both methods.
       Galaxy_Vision_V200.specsV200(CustomerName2);
       Galaxy_Vision_V200.displaypV200(CustomerName2);
   }
}
