package Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use;
public class Galaxy_Vision_V300
{
   static double taxV3, totalV3, priceV3;
   public static void specsV300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel i5 3000 3rd Gen 3.5 GHz\nRAM: 8 GB\nSSD: 5 TB\nGPU: Intel UHD Graphics 820 4GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Modern And Aesthetic look! It has a 2k face camera! This laptop has 8 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in White and Black Colour.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV3 = 150000;
     System.out.println("Base Price: ₹" + priceV3);
     double taxV3 = (0.15 * priceV3);
     System.out.println("Tax Price: ₹" + taxV3);
     totalV3 = taxV3 + priceV3;
     System.out.println("Total Price: ₹" + totalV3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV300(String CustomerName3)
   {
       //Call both methods.
       Galaxy_Vision_V300.specsV300(CustomerName3);
       Galaxy_Vision_V300.displaypV300(CustomerName3);
   }
}
