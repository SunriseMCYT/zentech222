package Zen_Tech.Laptops.Forza_Galaxy.For_Student_Use;
public class Forza_Galaxy_Vision_V100
{
   static double taxV1, totalV1, priceV1;
   public static void specsV100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel Pentium 4 2.80 GHz\nRAM: 4 GB\nSSD: 1 TB\nGPU: Intel Arc Pro A750 8GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Bold And Stylish look! It has a 720p face camera! This laptop has 3 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in White and Black Colour.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV1 = 75000;
     System.out.println("Base Price: ₹" + priceV1);
     double taxV1 = (0.8 * priceV1);
     System.out.println("Tax Price: ₹" + taxV1);
     totalV1 = taxV1 + priceV1;
     System.out.println("Total Price: ₹" + totalV1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV100(String CustomerName1)
   {
       //Call both methods.
       Forza_Galaxy_Vision_V100.specsV100(CustomerName1);
       Forza_Galaxy_Vision_V100.displaypV100(CustomerName1);
   }
}
