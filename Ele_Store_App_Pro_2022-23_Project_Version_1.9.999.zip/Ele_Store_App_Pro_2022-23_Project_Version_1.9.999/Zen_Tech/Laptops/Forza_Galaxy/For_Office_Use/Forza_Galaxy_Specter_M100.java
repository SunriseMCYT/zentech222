package Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use;
public class Forza_Galaxy_Specter_M100
{
   static double taxM1, totalM1, priceM1;
   public static void specsM100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: M100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i7 11850HE 11th gen 4.70 GHz\nRAM: 16 GB\n SSD: 10 TB\nGPU: NVIDIA RTX 2060 Ti 6GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an amazing look with Backlight keyboard! It has a 4k face camera! This laptop has a 24 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Yellow, Sky Blue and Scarlet Red.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypM100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceM1 = 250000;
     System.out.println("Base Price: ₹" + priceM1);
     double taxM1 = (0.15 * priceM1);
     System.out.println("Tax Price: ₹" + taxM1);
     totalM1 = taxM1 + priceM1;
     System.out.println("Total Price: ₹" + totalM1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationM100(String CustomerName1)
   {
       //Call both methods.
       Forza_Galaxy_Specter_M100.specsM100(CustomerName1);
       Forza_Galaxy_Specter_M100.displaypM100(CustomerName1);
   }
}
