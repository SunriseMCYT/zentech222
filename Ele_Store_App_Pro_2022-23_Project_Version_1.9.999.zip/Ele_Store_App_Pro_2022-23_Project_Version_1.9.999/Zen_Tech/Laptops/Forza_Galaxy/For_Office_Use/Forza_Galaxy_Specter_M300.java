package Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use;
public class Forza_Galaxy_Specter_M300
{
   static double taxM3, totalM3, priceM3;
   public static void specsM300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: M300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i7 10700k 10th gen 5.10 GHz\nRAM: 64 GB\n SSD: 20 TB\nGPU: Intel Arc Pro A750 8GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Ultra Thin And Light look with Backlight keyboard! It has a 16k face camera! This laptop has a 32 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in White, Sky Blue and Scarlet Red.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypM300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceM3 = 250000;
     System.out.println("Base Price: ₹" + priceM3);
     double taxM3 = (0.15 * priceM3);
     System.out.println("Tax Price: ₹" + taxM3);
     totalM3 = taxM3 + priceM3;
     System.out.println("Total Price: ₹" + totalM3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationM300(String CustomerName3)
   {
       //Call both methods.
       Forza_Galaxy_Specter_M300.specsM300(CustomerName3);
       Forza_Galaxy_Specter_M300.displaypM300(CustomerName3);
   }
}
