package Zen_Tech.Laptops.Forza_Galaxy.For_Office_Use;
public class Forza_Galaxy_Specter_M200
{
   static double taxM2, totalM2, priceM2;
   public static void specsM200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: M200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i7 12700UL 12th gen 4.90 GHz\nRAM: 32 GB\n SSD: 15 TB\nGPU: NVIDIA RTX 3060 OC 12GB");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an sleek look with Backlight keyboard! It has a 8k face camera! This laptop has a 29 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Black, Sky Blue and Scarlet Red.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypM200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceM2 = 450000;
     System.out.println("Base Price: ₹" + priceM2);
     double taxM2 = (0.15 * priceM2);
     System.out.println("Tax Price: ₹" + taxM2);
     totalM2 = taxM2 + priceM2;
     System.out.println("Total Price: ₹" + totalM2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationM200(String CustomerName2)
   {
       //Call both methods.
       Forza_Galaxy_Specter_M200.specsM200(CustomerName2);
       Forza_Galaxy_Specter_M200.displaypM200(CustomerName2);
   }
}
