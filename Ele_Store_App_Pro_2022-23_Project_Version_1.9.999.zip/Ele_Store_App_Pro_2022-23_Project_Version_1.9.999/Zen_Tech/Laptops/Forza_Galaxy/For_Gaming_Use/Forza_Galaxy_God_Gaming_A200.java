package Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use;
public class Forza_Galaxy_God_Gaming_A200
{
   static double taxA2, totalA2, priceA2;
       public static void specsA200(String CustomerName)
       {
     System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: A200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i9 13900k 13th gen GHz 5.80\nRAM: Total of 1028 GB with 128x8 sticks\nSSD: 20 TB\nGPU: NVIDIA RTX 4090 Ti 48Gb x2B ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has a tough and chobblesome look with RGB keyboard! It has a 8k front camera! This laptop has a 16 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Gold, Titanium and Velvet Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypA200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceA2 = 1000000;
     System.out.println("Base Price: ₹" + priceA2);
     double taxA2 = (0.15 * priceA2);
     System.out.println("Tax Price: ₹" + taxA2);
     totalA2 = taxA2 + priceA2;
     System.out.println("Total Price: ₹" + totalA2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
      public static void full_documentationA200(String customernameA200)
   {
     //Call both methods.
     Forza_Galaxy_God_Gaming_A200.specsA200(customernameA200);
     Forza_Galaxy_God_Gaming_A200.displaypA200(customernameA200);
   }
}
