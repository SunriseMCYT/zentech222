package Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use;
public class Forza_Galaxy_God_Gaming_A100
{
   static double taxA1, totalA1, priceA1;
   public static void specsA100(String Name)
   {
    System.out.println("Hi," +Name);
     System.out.println("                                                           Model No: A100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i9 13900k 13th gen 5.80GHz\nRAM: 32 GB\n SSD: 5 TB\nGPU: NVIDIA RTX 4090 Ti 48Gb");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an amazing look with RGB keyboard! It has a 4k face camera! This laptop has a 12 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in White, Red and Black Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypA100(String Name)
   {
     System.out.println("Dear " + Name + ", your total billing is as follows.");
     priceA1 = 400000;
     System.out.println("Base Price: ₹" + priceA1);
     double taxA1 = (0.15 * priceA1);
     System.out.println("Tax Price: ₹" + taxA1);
     totalA1 = taxA1 + priceA1;
     System.out.println("Total Price: ₹" + totalA1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationA100(String Name)
   {
       //Call both methods.
       Forza_Galaxy_God_Gaming_A100.specsA100(Name);
       Forza_Galaxy_God_Gaming_A100.displaypA100(Name);
   }
}
