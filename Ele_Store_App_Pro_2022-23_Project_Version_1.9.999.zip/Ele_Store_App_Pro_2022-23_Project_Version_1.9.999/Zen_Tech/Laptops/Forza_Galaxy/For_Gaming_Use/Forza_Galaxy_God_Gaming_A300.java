 package Zen_Tech.Laptops.Forza_Galaxy.For_Gaming_Use;
public class Forza_Galaxy_God_Gaming_A300
{
   static double taxA3, totalA3, priceA3;
   public static void specsA300(String CustomerName)
   {
     System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: A300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i5 13600k 13th gen GHz 5.10\nRAM: Total of 16 GB with 4x4 sticks\nSSD: 1.5 TB\nGPU: NVIDIA RTX 3050 Ti 4GB ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has a Nice, compact and sleek model look with RGB keyboard! It has a 720p front camera! This laptop has a 5 battery life on 1 full charge!");
     System.out.println("This laptop is available in White, Silver and Maroon.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypA300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceA3 = 100000;
     System.out.println("Base Price: ₹" + priceA3);
     double taxA3 = (0.15 * priceA3);
     System.out.println("Tax Price: ₹" + taxA3);
     totalA3 = taxA3 + priceA3;
     System.out.println("Total Price: ₹" + totalA3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
      public static void full_documentationA300(String customernameA300)
   {
     //Call both methods.
     Forza_Galaxy_God_Gaming_A300.specsA300(customernameA300);
     Forza_Galaxy_God_Gaming_A300.displaypA300(customernameA300);
   }
}
