package Zen_Tech.Laptops.Opera.For_Gaming_Use;
public class Opera_Fireyzen_G300
{
   static double taxG3, totalG3, priceG3;
   public static void specsG300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: G300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: intel i9 13900k 13th gen 5.40 GHz\nRAM: 32 GB\nSSD: 7 TB\nGPU: NVIDIA RTX 2080 Ti 16Gb x 4");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has a compact look with RGB keyboard! It has a 16k face camera! This laptop has a 24 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Mountain White, Bloody Red, Sap Green, Lemon Yellow, Pigeon Gray and Sunlight Yellow Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypG300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceG3 = 700000;
     System.out.println("Base Price: ₹" + priceG3);
     double taxG3 = (0.5 * priceG3);
     System.out.println("Tax Price: ₹" + taxG3);
     totalG3 = taxG3 + priceG3;
     System.out.println("Total Price: ₹" + totalG3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationG300(String CustomerName3)
   {
       //Call both methods.
       Opera_Fireyzen_G300.specsG300(CustomerName3);
       Opera_Fireyzen_G300.displaypG300(CustomerName3);
   }
}

