package Zen_Tech.Laptops.Opera.For_Gaming_Use;
public class Opera_Fireyzen_G200
{
   static double taxG2, totalG2, priceG2;
   public static void specsG200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: G200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: intel i7 13700 13th gen 5.10 GHz\nRAM: 16 GB\nSSD: 5 TB\nGPU: NVIDIA RTX 2080 Ti 16Gb");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has a compact look with RGB keyboard! It has a 8k face camera! This laptop has a 24 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Mountain White, Bloody Red and  Sunlight Yellow Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypG200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceG2 = 175000;
     System.out.println("Base Price: ₹" + priceG2);
     double taxG2 = (0.15 * priceG2);
     System.out.println("Tax Price: ₹" + taxG2);
     totalG2 = taxG2 + priceG2;
     System.out.println("Total Price: ₹" + totalG2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationG200(String CustomerName2)
   {
       //Call both methods.
       Opera_Fireyzen_G200.specsG200(CustomerName2);
       Opera_Fireyzen_G200.displaypG200(CustomerName2);
   }
}

