package Zen_Tech.Laptops.Opera.For_Gaming_Use;
public class Opera_Fireyzen_G100
{
   static double taxG1, totalG1, priceG1;
   public static void specsG100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: G100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: AMD Ryzen 9 7950x 5.7 GHz\nRAM: 64 GB\nSSD: 2 TB\nGPU: NVIDIA RTX 4090 Ti 48Gb x 4");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Fiery look with RGB keyboard! It has a 16k face camera! This laptop has a 48 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Emerald Green, Topaz Blue, Garnet Red Colours.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypG100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceG1 = 1000000;
     System.out.println("Base Price: ₹" + priceG1);
     double taxG1 = (0.15 * priceG1);
     System.out.println("Tax Price: ₹" + taxG1);
     totalG1 = taxG1 + priceG1;
     System.out.println("Total Price: ₹" + totalG1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationG100(String CustomerName1)
   {
       //Call both methods.
       Opera_Fireyzen_G100.specsG100(CustomerName1);
       Opera_Fireyzen_G100.displaypG100(CustomerName1);
   }
}

