package Zen_Tech.Laptops.Opera.For_Office_Use;

public class Opera_Victor_V200
{
   static double taxV2, totalV2, priceV2;
   public static void specsV200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: CPU: i7 1255UL 12th gen 1.70 GHz\nRAM: 32 GB\nSSD: 10 TB\nGPU: NVIDIA Quadro RTX 8000 48Gb ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Sleek look with a Smooth keyboard! It has a 8k face camera! \nThis laptop has a 16 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Aquamarine Blue, Lapiz Lazuli Purple, Agate Rust.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV2 = 820000;
     System.out.println("Base Price: ₹" + priceV2);
     double taxV2 = (0.09 * priceV2);
     System.out.println("Tax Price: ₹" + taxV2);
     totalV2 = taxV2 + priceV2;
     System.out.println("Total Price: ₹" + totalV2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV200(String CustomerName1)
   {
       //Call both methods.
       Opera_Victor_V200.specsV200(CustomerName1);
       Opera_Victor_V200.displaypV200(CustomerName1);
   }
}

