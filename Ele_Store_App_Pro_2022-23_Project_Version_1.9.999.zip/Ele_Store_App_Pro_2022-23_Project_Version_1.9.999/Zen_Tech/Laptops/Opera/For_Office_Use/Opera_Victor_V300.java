package Zen_Tech.Laptops.Opera.For_Office_Use;

public class Opera_Victor_V300
{
   static double taxV3, totalV3, priceV3;
   public static void specsV300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V300");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i9 13900K 13th gen 5.80 GHz\nRAM: 64 GB\nSSD: 15 TB\nGPU: NVIDIA TITAN V 12Gb ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Innovative look with Shiny and Customisable Backlight keyboard! It has a 16k face camera! \nThis laptop has a 8 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Amethyst Purple, Peridot Green, Alexanderite Cyan .");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV3 = 1000000;
     System.out.println("Base Price: ₹" + priceV3);
     double taxV3 = (0.15 * priceV3);
     System.out.println("Tax Price: ₹" + taxV3);
     totalV3 = taxV3 + priceV3;
     System.out.println("Total Price: ₹" + totalV3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV300(String CustomerName1)
   {
       //Call both methods.
       Opera_Victor_V300.specsV300(CustomerName1);
       Opera_Victor_V300.displaypV300(CustomerName1);
   }
}

