package Zen_Tech.Laptops.Opera.For_Office_Use;

public class Opera_Victor_V100
{
   static double taxV1, totalV1, priceV1;
   public static void specsV100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: V100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: i5 10505 10th Gen 3.2 GHz\nRAM: 16 GB\nSSD: 5 TB\nGPU: NVIDIA Quadro RTX 4000 8Gb ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has an Modern look with LED Backlight keyboard! It has a 4k face camera! \nThis laptop has a 24 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Quartz White And Matte Black.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypV100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceV1 = 500000;
     System.out.println("Base Price: ₹" + priceV1);
     double taxV1 = (0.15 * priceV1);
     System.out.println("Tax Price: ₹" + taxV1);
     totalV1 = taxV1 + priceV1;
     System.out.println("Total Price: ₹" + totalV1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationV100(String CustomerName1)
   {
       //Call both methods.
       Opera_Victor_V100.specsV100(CustomerName1);
       Opera_Victor_V100.displaypV100(CustomerName1);
   }
}

