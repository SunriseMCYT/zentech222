package Zen_Tech.Laptops.Opera;
public class Opera_About_Us
{
    public static void display()
    {
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
     System.out.println("                                                    Opera Galaxy");
     System.out.println("* About Our Brand!:");
     System.out.println("* Our motto: Acheiving Excellence");
     System.out.println("* Our centre is situated in London.");
     System.out.println("* We offer Gaming laptops, Office Laptops and Student Laptops.");
     System.out.println("* We ensure 24x7 public support.");
     System.out.println("* Our review on trustpilot is 4.9 stars out 5!");
     System.out.println("* Many companies like Microsoft, Apple, Samsung, Nokia, Facebook and Whatsapp buy products from us!");
     System.out.println("* We are the most gamer friendly company out there!");
     System.out.println("* We believe in sustainable environemt, so we use recycled material to create new, better and faster products.");
     System.out.println("* We have products from a base price of ₹1,75,000/- to ₹10,00,000/-.");
     System.out.println("* -----------------------------------------------------------------------------------------------------------*");
 }
}

