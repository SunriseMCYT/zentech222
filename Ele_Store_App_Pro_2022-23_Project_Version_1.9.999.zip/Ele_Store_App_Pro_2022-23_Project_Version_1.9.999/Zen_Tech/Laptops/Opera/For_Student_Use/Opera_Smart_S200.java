package Zen_Tech.Laptops.Opera.For_Student_Use;

public class Opera_Smart_S200
{
   static double taxS2, totalS2, priceS2;
   public static void specsS200(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S200");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel 8080  0.002GHz\nRAM: 8 GB\nSSD: 15 GB\nGPU: Radeon M470X 4Gb ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has Retro look! It has a 720p face camera! \nThis laptop has a 8 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Calcite Grey Colour.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS200(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS2 = 700000;
     System.out.println("Base Price: ₹" + priceS2);
     double taxS2 = (0.001 * priceS2);
     System.out.println("Tax Price: ₹" + taxS2);
     totalS2 = taxS2 + priceS2;
     System.out.println("Total Price: ₹" + totalS2);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS200(String CustomerName1)
   {
       //Call both methods.
       Opera_Smart_S200.specsS200(CustomerName1);
       Opera_Smart_S200.displaypS200(CustomerName1);
   }
}

