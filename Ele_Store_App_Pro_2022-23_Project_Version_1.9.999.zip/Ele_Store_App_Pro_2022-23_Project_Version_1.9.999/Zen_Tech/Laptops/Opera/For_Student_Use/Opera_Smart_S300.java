package Zen_Tech.Laptops.Opera.For_Student_Use;

public class Opera_Smart_S300
{
   static double taxS3, totalS3, priceS3;
   public static void specsS300(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel 4004 0.00074 GHzPentium Pro 0.2 GHz\nRAM: 8 GB\nSSD: 20 GB\nGPU: EVGA GeForce 6200 512 MB ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has Retro look! It has a 1080p face camera! \nThis laptop has a 12 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Tanzanite Blue.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS300(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS3 = 800000;
     System.out.println("Base Price: ₹" + priceS3);
     double taxS3 = (0.02 * priceS3);
     System.out.println("Tax Price: ₹" + taxS3);
     totalS3 = taxS3 + priceS3;
     System.out.println("Total Price: ₹" + totalS3);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS300(String CustomerName1)
   {
       //Call both methods.
       Opera_Smart_S300.specsS300(CustomerName1);
       Opera_Smart_S300.displaypS300(CustomerName1);
   }
}

