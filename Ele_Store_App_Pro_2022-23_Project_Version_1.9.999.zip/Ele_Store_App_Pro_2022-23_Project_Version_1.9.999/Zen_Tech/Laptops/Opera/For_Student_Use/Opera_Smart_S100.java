package Zen_Tech.Laptops.Opera.For_Student_Use;

public class Opera_Smart_S100
{
   static double taxS1, totalS1, priceS1;
   public static void specsS100(String CustomerName)
   {
    System.out.println("Hi," +CustomerName);
     System.out.println("                                                           Model No: S100");
     System.out.println("*-------------- ------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("Laptop Specs: \nCPU: Intel 4004 0.00074 GHz\nRAM: 4 GB\nSSD: 10 GB\nGPU: Glenfly Aris GT10C0 2Gb ");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
     System.out.println("This laptop has Retro look! It has a 360p face camera! \nThis laptop has a 1 hour battery life on 1 full charge!");
     System.out.println("This laptop is available in Black Opal Colour.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void displaypS100(String Customer)
   {
     System.out.println("Dear " + Customer + ", your total billing is as follows.");
     priceS1 = 300000;
     System.out.println("Base Price: ₹" + priceS1);
     double taxS1 = (0.50 * priceS1);
     System.out.println("Tax Price: ₹" + taxS1);
     totalS1 = taxS1 + priceS1;
     System.out.println("Total Price: ₹" + totalS1);
     System.out.println("You can pay using UPI, Credit, Debit Card, Netbanking and Crypto.");
     System.out.println("*--------------------------------------------------------------------------------------------------------------------------------------------*");
   }
   public static void full_documentationS100(String CustomerName1)
   {
       //Call both methods.
       Opera_Smart_S100.specsS100(CustomerName1);
       Opera_Smart_S100.displaypS100(CustomerName1);
   }
}

